# How to Put Your EMI Calculator Website Live
## Complete Beginner Guide – Step by Step

---

## WHAT YOU HAVE (3 FILES)
- index.html  → The webpage structure
- style.css   → The colors, fonts, design
- script.js   → The calculation logic

All 3 files must stay in the SAME folder.

---

## OPTION 1: Open on Your Computer (Test First)
1. Download the 3 files into one folder (e.g. "auxilo-calculator")
2. Double-click index.html
3. It opens in your browser — your calculator is working!

---

## OPTION 2: Put it Online FREE using GitHub Pages

### Step A – Create a GitHub account
1. Go to https://github.com
2. Click "Sign up" (top right)
3. Enter email, password, username
4. Verify your email

### Step B – Create a new repository (like a folder online)
1. Click the green "New" button on GitHub
2. Repository name: auxilo-calculator
3. Set it to PUBLIC
4. Click "Create repository"

### Step C – Upload your files
1. On the repository page, click "uploading an existing file"
2. Drag and drop all 3 files:
   - index.html
   - style.css
   - script.js
3. Scroll down, click "Commit changes"

### Step D – Turn on GitHub Pages (makes it a real website)
1. Click "Settings" tab (top of your repository)
2. Scroll down to "Pages" in the left menu
3. Under "Branch" select "main" and click Save
4. Wait 1-2 minutes
5. Your website is now LIVE at:
   https://YOUR-USERNAME.github.io/auxilo-calculator/

---

## OPTION 3: Even Simpler – Use Netlify Drop

1. Go to https://netlify.com/drop
2. Drag your entire "auxilo-calculator" folder onto the page
3. That's it! You get a live URL in seconds
4. Example: https://random-name-123.netlify.app

---

## HOW TO MAKE CHANGES LATER

### Change the company name:
Open index.html → Find "AUXILO" → Change to your company name

### Change default values:
Open index.html → Find value="76000" → Change to your default loan amount
Open index.html → Find value="17.29" → Change to your default interest rate

### Change colors:
Open style.css → Find background: #0d2044 → That's the dark blue header color
Open style.css → Find background: #1a56db → That's the button color

---

## IF SOMETHING IS NOT WORKING

Problem: Page looks broken (no colors)
Fix: Make sure style.css is in the SAME folder as index.html

Problem: Calculate button does nothing
Fix: Make sure script.js is in the SAME folder as index.html

Problem: Website not showing after GitHub Pages setup
Fix: Wait 5 minutes and refresh. It takes time the first time.

---

## NEED CUSTOM DOMAIN? (e.g. www.auxilo.com)
1. Buy domain from GoDaddy / Namecheap / BigRock (India)
2. In GitHub Pages settings, enter your domain in "Custom domain"
3. In your domain registrar, add a CNAME record pointing to:
   YOUR-USERNAME.github.io

---

Questions? The 3 files are ready to use as-is.
Just open index.html in a browser to see it work!
