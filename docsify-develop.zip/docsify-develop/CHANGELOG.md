# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [5.0.0-rc.4](https://github.com/docsifyjs/docsify/compare/v5.0.0-rc.3...v5.0.0-rc.4) (2026-03-11)


### Bug Fixes

* adjust intersection observer threshold for sticky class toggle ([#2637](https://github.com/docsifyjs/docsify/issues/2637)) ([4e8be38](https://github.com/docsifyjs/docsify/commit/4e8be38304ad5fcf64c585f42afef46c72adabb7))
* enhance accessibility for sidebar toggle button ([#2604](https://github.com/docsifyjs/docsify/issues/2604)) ([3014945](https://github.com/docsifyjs/docsify/commit/3014945e4d677d24124a3a01fe88ec82951ebfa7))
* improve word breaking for code blocks in markdown ([#2636](https://github.com/docsifyjs/docsify/issues/2636)) ([73d41e9](https://github.com/docsifyjs/docsify/commit/73d41e9e48ab7effae4c5dffd4aec4bd4e1b9168))
* include h6 headings in heading element selection ([#2649](https://github.com/docsifyjs/docsify/issues/2649)) ([44326ca](https://github.com/docsifyjs/docsify/commit/44326ca423b25ddbb12b172ab7180edd553c61f4))
* strip HTML tags from config.name when setting page title ([#2690](https://github.com/docsifyjs/docsify/issues/2690)) ([0cfee34](https://github.com/docsifyjs/docsify/commit/0cfee34dbc0d511a272070e4124eb2f3102d988e)), closes [#2610](https://github.com/docsifyjs/docsify/issues/2610)
* typo ([#2632](https://github.com/docsifyjs/docsify/issues/2632)) ([2d45376](https://github.com/docsifyjs/docsify/commit/2d45376bb8dc3f7a07c633a7be4d38af3a56501b))


### Features

* add fallback default language support ([#2607](https://github.com/docsifyjs/docsify/issues/2607)) ([1abe3a9](https://github.com/docsifyjs/docsify/commit/1abe3a9ea48cd3a96ee65cd958090bf2936de3c9))
* enhance embed handling for table cells ([#2606](https://github.com/docsifyjs/docsify/issues/2606)) ([422a745](https://github.com/docsifyjs/docsify/commit/422a745acc4783c325d55413c5349ca70c42c67c))
* Fragment identifier full line ignore ([#2626](https://github.com/docsifyjs/docsify/issues/2626)) ([e811756](https://github.com/docsifyjs/docsify/commit/e8117563eae4aa9468c36b76fe83c5ce3f7423ea))
* output type definitions, and allow `new Docsify(opts)` to accept options for ESM usage ([#2392](https://github.com/docsifyjs/docsify/issues/2392)) ([b960519](https://github.com/docsifyjs/docsify/commit/b960519608747015d1ab974c9ed809c21f3b1bda))



## [5.0.0-rc.3](https://github.com/docsifyjs/docsify/compare/v5.0.0-rc.1...v5.0.0-rc.3) (2025-09-05)


### Bug Fixes

* enhance focus handling ([#2595](https://github.com/docsifyjs/docsify/issues/2595)) ([22ac7e8](https://github.com/docsifyjs/docsify/commit/22ac7e855de24b13280e9904930e58af58dbd6a7))
* enhance focus handling by adding smooth scroll to content area ([#2569](https://github.com/docsifyjs/docsify/issues/2569)) ([20d095b](https://github.com/docsifyjs/docsify/commit/20d095b53c827c4d0590dee5fd377ba21560d7fb))
* escape HTML in search keywords ([#2586](https://github.com/docsifyjs/docsify/issues/2586)) ([743e9cb](https://github.com/docsifyjs/docsify/commit/743e9cb484cc70859a582fb74d78ea1f52ef2c2a))
* exclude app-name-link from sidebar text overflow styling ([#2564](https://github.com/docsifyjs/docsify/issues/2564)) ([375c058](https://github.com/docsifyjs/docsify/commit/375c058e3e1b12f3507d97a41b3fd8d6c4e904b0))
* handle hash navigation to prevent duplicate callbacks ([#2575](https://github.com/docsifyjs/docsify/issues/2575)) ([72569de](https://github.com/docsifyjs/docsify/commit/72569dee8db92a01e8de5448e05c32afbd090fb2))
* heading link overflow style ([#2568](https://github.com/docsifyjs/docsify/issues/2568)) ([be21637](https://github.com/docsifyjs/docsify/commit/be2163725ae314de3aa9a56c1216ce8c774cfcc6))
* improve slug generation ([#2581](https://github.com/docsifyjs/docsify/issues/2581)) ([9bc58c9](https://github.com/docsifyjs/docsify/commit/9bc58c9ca24db513a90a06752181954aab0628ca))
* normalize slugs to NFC and remove emoji variation selector ([#2597](https://github.com/docsifyjs/docsify/issues/2597)) ([5999f09](https://github.com/docsifyjs/docsify/commit/5999f09a4bac23169766af68fbdc71215161c1c6))
* remove block display from anchor links to prevent layout issues ([#2576](https://github.com/docsifyjs/docsify/issues/2576)) ([6e45024](https://github.com/docsifyjs/docsify/commit/6e4502416886b9494cd7b510968c351c7e6fc3cd))
* **sidebar:** remove ignored headings and children ([#2580](https://github.com/docsifyjs/docsify/issues/2580)) ([2a49bd0](https://github.com/docsifyjs/docsify/commit/2a49bd0aa4bb17eeb3d9f363c6f2b01e61e778ac))
* update relative link handling ([#2579](https://github.com/docsifyjs/docsify/issues/2579)) ([eeacfcc](https://github.com/docsifyjs/docsify/commit/eeacfcce2a3df4e4146b5b54275553452b317352))


### Features

* GitHub style callouts ([#2487](https://github.com/docsifyjs/docsify/issues/2487)) ([2e59b0f](https://github.com/docsifyjs/docsify/commit/2e59b0f50cf8123b98e4c97c3053aa6985ae13a2))
* support config helper multi keys if supported ([#2571](https://github.com/docsifyjs/docsify/issues/2571)) ([a2f734f](https://github.com/docsifyjs/docsify/commit/a2f734f223cae475aefe7d41995a2030a1f9c0a2))
* support extract content between fragment markers from Markdown ([#2582](https://github.com/docsifyjs/docsify/issues/2582)) ([32aa74e](https://github.com/docsifyjs/docsify/commit/32aa74e0d2fcd89705e5c30fc8b8e2562e7b774e))



## [5.0.0-rc.2](https://github.com/docsifyjs/docsify/compare/v5.0.0-rc.1...v5.0.0-rc.2) (2025-09-05)


### Bug Fixes

* enhance focus handling ([#2595](https://github.com/docsifyjs/docsify/issues/2595)) ([22ac7e8](https://github.com/docsifyjs/docsify/commit/22ac7e855de24b13280e9904930e58af58dbd6a7))
* enhance focus handling by adding smooth scroll to content area ([#2569](https://github.com/docsifyjs/docsify/issues/2569)) ([20d095b](https://github.com/docsifyjs/docsify/commit/20d095b53c827c4d0590dee5fd377ba21560d7fb))
* escape HTML in search keywords ([#2586](https://github.com/docsifyjs/docsify/issues/2586)) ([743e9cb](https://github.com/docsifyjs/docsify/commit/743e9cb484cc70859a582fb74d78ea1f52ef2c2a))
* exclude app-name-link from sidebar text overflow styling ([#2564](https://github.com/docsifyjs/docsify/issues/2564)) ([375c058](https://github.com/docsifyjs/docsify/commit/375c058e3e1b12f3507d97a41b3fd8d6c4e904b0))
* handle hash navigation to prevent duplicate callbacks ([#2575](https://github.com/docsifyjs/docsify/issues/2575)) ([72569de](https://github.com/docsifyjs/docsify/commit/72569dee8db92a01e8de5448e05c32afbd090fb2))
* heading link overflow style ([#2568](https://github.com/docsifyjs/docsify/issues/2568)) ([be21637](https://github.com/docsifyjs/docsify/commit/be2163725ae314de3aa9a56c1216ce8c774cfcc6))
* improve slug generation ([#2581](https://github.com/docsifyjs/docsify/issues/2581)) ([9bc58c9](https://github.com/docsifyjs/docsify/commit/9bc58c9ca24db513a90a06752181954aab0628ca))
* remove block display from anchor links to prevent layout issues ([#2576](https://github.com/docsifyjs/docsify/issues/2576)) ([6e45024](https://github.com/docsifyjs/docsify/commit/6e4502416886b9494cd7b510968c351c7e6fc3cd))
* **sidebar:** remove ignored headings and children ([#2580](https://github.com/docsifyjs/docsify/issues/2580)) ([2a49bd0](https://github.com/docsifyjs/docsify/commit/2a49bd0aa4bb17eeb3d9f363c6f2b01e61e778ac))
* update relative link handling ([#2579](https://github.com/docsifyjs/docsify/issues/2579)) ([eeacfcc](https://github.com/docsifyjs/docsify/commit/eeacfcce2a3df4e4146b5b54275553452b317352))


### Features

* GitHub style callouts ([#2487](https://github.com/docsifyjs/docsify/issues/2487)) ([2e59b0f](https://github.com/docsifyjs/docsify/commit/2e59b0f50cf8123b98e4c97c3053aa6985ae13a2))
* support config helper multi keys if supported ([#2571](https://github.com/docsifyjs/docsify/issues/2571)) ([a2f734f](https://github.com/docsifyjs/docsify/commit/a2f734f223cae475aefe7d41995a2030a1f9c0a2))
* support extract content between fragment markers from Markdown ([#2582](https://github.com/docsifyjs/docsify/issues/2582)) ([32aa74e](https://github.com/docsifyjs/docsify/commit/32aa74e0d2fcd89705e5c30fc8b8e2562e7b774e))



## [5.0.0-rc.1](https://github.com/docsifyjs/docsify/compare/v4.13.1...v5.0.0-rc.1) (2025-05-27)


### Bug Fixes

* auto header config heading generate func ([#2474](https://github.com/docsifyjs/docsify/issues/2474)) ([4bc5062](https://github.com/docsifyjs/docsify/commit/4bc5062fc13a3a43c7ed432f1b585fdab41f1447))
* carbon broken ([#2387](https://github.com/docsifyjs/docsify/issues/2387)) ([87fd55d](https://github.com/docsifyjs/docsify/commit/87fd55d7125539b929f3260fca92e666e988b6da))
* **ci:** run test action for pull requests ([#2445](https://github.com/docsifyjs/docsify/issues/2445)) ([15ed3b7](https://github.com/docsifyjs/docsify/commit/15ed3b76b00eac06cc4230b1f592993adf2a893b))
* correct loadSidebar=false render structure issue ([#2470](https://github.com/docsifyjs/docsify/issues/2470)) ([7cbd532](https://github.com/docsifyjs/docsify/commit/7cbd5322d056bb87b4340bdb19909a9c32d19abb))
* dev mode hot reload and add sourcemaps ([#2402](https://github.com/docsifyjs/docsify/issues/2402)) ([947d8de](https://github.com/docsifyjs/docsify/commit/947d8decb8c5c62f3ce50d0c6ac0e27bb6c7a6b5))
* enhancement of isExternal ([#2093](https://github.com/docsifyjs/docsify/issues/2093)) ([7f13ba0](https://github.com/docsifyjs/docsify/commit/7f13ba0f9841776008d0707f027bd80c4e3cbf0c))
* fix cross-origin links in history router mode ([#1967](https://github.com/docsifyjs/docsify/issues/1967)) ([ef6905b](https://github.com/docsifyjs/docsify/commit/ef6905b53a5c1587c3ebf870f0d11ff111a2350d))
* fix dependabot.yml ([a321e83](https://github.com/docsifyjs/docsify/commit/a321e8373b3c6afc9d0b08714e34bd8bd68716d9))
* fix docsify-server-renderer dependency. ([#1915](https://github.com/docsifyjs/docsify/issues/1915)) ([c73f858](https://github.com/docsifyjs/docsify/commit/c73f8587b2f67e28c228e521518110ff504cefeb))
* fix id with pure number. ([#2021](https://github.com/docsifyjs/docsify/issues/2021)) ([f4f21a3](https://github.com/docsifyjs/docsify/commit/f4f21a3f74d265f16b1e658feda417bf851458da))
* genIndex error for search ([#1933](https://github.com/docsifyjs/docsify/issues/1933)) ([a8f9fc1](https://github.com/docsifyjs/docsify/commit/a8f9fc1d5f5c7808efe65e5ca9359f38014b1bcd))
* husky can not auto install issue after upgrade. ([#2325](https://github.com/docsifyjs/docsify/issues/2325)) ([cec43d7](https://github.com/docsifyjs/docsify/commit/cec43d71774556d38fa9746f4df4319a6ad768c2))
* parse heading error ([#2526](https://github.com/docsifyjs/docsify/issues/2526)) ([561c777](https://github.com/docsifyjs/docsify/commit/561c777df898a71f8b44b25e5946b56eb1d2c106))
* Prevent initial unnecessary IntersectionObserver callback execution ([#2523](https://github.com/docsifyjs/docsify/issues/2523)) ([a73e07e](https://github.com/docsifyjs/docsify/commit/a73e07eac06a70f63896e2bb7f0c205534dc21c8))
* prevent unnecessary themeColor deprecation notice ([#2403](https://github.com/docsifyjs/docsify/issues/2403)) ([a3ab2be](https://github.com/docsifyjs/docsify/commit/a3ab2be0b070a1bacc4fec3c2d2f0ffe279bada0))
* **search:** clean markdown elements in search contents ([#2457](https://github.com/docsifyjs/docsify/issues/2457)) ([95901eb](https://github.com/docsifyjs/docsify/commit/95901eb8a829865c883a4374c53a0b8909b53c41))
* skip-to-content scroll behavior ([#2401](https://github.com/docsifyjs/docsify/issues/2401)) ([2d986fe](https://github.com/docsifyjs/docsify/commit/2d986feb34fcdb2a2731cff7b29b0a4d0563787e))
* sync the page title regarding the title config ([#2478](https://github.com/docsifyjs/docsify/issues/2478)) ([2eec7c4](https://github.com/docsifyjs/docsify/commit/2eec7c4884146add6e0c8142e463cfad34fb7637))
* upgrade debug from 4.3.3 to 4.3.4 ([#1919](https://github.com/docsifyjs/docsify/issues/1919)) ([0c9221e](https://github.com/docsifyjs/docsify/commit/0c9221e5a425984470ebc89ffb682e988b08b06e))
* upgrade medium-zoom from 1.0.6 to 1.0.7 ([#1934](https://github.com/docsifyjs/docsify/issues/1934)) ([2601392](https://github.com/docsifyjs/docsify/commit/26013929ccf1927cc6a46c5455fb70f71d90492f))
* upgrade medium-zoom from 1.0.7 to 1.0.8 ([#1939](https://github.com/docsifyjs/docsify/issues/1939)) ([81fc1b7](https://github.com/docsifyjs/docsify/commit/81fc1b7dce15d74bb025d3f95bfa5dae55540a10))
* upgrade node-fetch from 2.6.8 to 2.6.9 ([#1996](https://github.com/docsifyjs/docsify/issues/1996)) ([bb88d63](https://github.com/docsifyjs/docsify/commit/bb88d6302b22b2484cca6436c7b4279d5e7fc5ea))
* When alias contains parameters, append ext error ([#1855](https://github.com/docsifyjs/docsify/issues/1855)) ([1a32fb7](https://github.com/docsifyjs/docsify/commit/1a32fb73347308696f6e82c0757ba081a4e7b8de))


### Features

* Add "Skip to main content" link and update nav behavior ([#2253](https://github.com/docsifyjs/docsify/issues/2253)) ([50b84f7](https://github.com/docsifyjs/docsify/commit/50b84f74b25c27f1a3a102055e7f099db31155f8))
* add google analytics gtag.js plugin ([#1702](https://github.com/docsifyjs/docsify/issues/1702)) ([29f3c82](https://github.com/docsifyjs/docsify/commit/29f3c82faaffb817d2149d23a0e3a884cd1cc843))
* Allow top nav to receive keyboard focus ([#2269](https://github.com/docsifyjs/docsify/issues/2269)) ([4d5bf5a](https://github.com/docsifyjs/docsify/commit/4d5bf5ac48499c57cfdffd98bfaa29bf20d85260))
* Keyboard bindings ([#2279](https://github.com/docsifyjs/docsify/issues/2279)) ([cf61192](https://github.com/docsifyjs/docsify/commit/cf61192f9a467c96372bce9e4e371a3f0c6a1780))
* **search:** use dexie.js instead of localStorage ([#2464](https://github.com/docsifyjs/docsify/issues/2464)) ([42f2548](https://github.com/docsifyjs/docsify/commit/42f25482fa1ea6ec666800145f6da33e9119aa8c))
* Support dark mode for zoom-image plugin ([#2524](https://github.com/docsifyjs/docsify/issues/2524)) ([5826863](https://github.com/docsifyjs/docsify/commit/58268632c8ebc2855c38305a05b8326727e388c1))
* support prism langs dependencies import validation ([#2489](https://github.com/docsifyjs/docsify/issues/2489)) ([87e43f1](https://github.com/docsifyjs/docsify/commit/87e43f157f749dda01b54e33117ef851b12bda7c))
* support relative path with target config. ([#1751](https://github.com/docsifyjs/docsify/issues/1751)) ([e15ad0c](https://github.com/docsifyjs/docsify/commit/e15ad0c7d530287692e98ca587f8f07d90624919))
* v5 style overhaul ([#2469](https://github.com/docsifyjs/docsify/issues/2469)) ([77d93fa](https://github.com/docsifyjs/docsify/commit/77d93fae7886346e739285630ea865ac8197149e))



## [4.13.1](https://github.com/docsifyjs/docsify/compare/v4.13.0...v4.13.1) (2023-06-24)


### Bug Fixes

* enhancement of isExternal ([#2093](https://github.com/docsifyjs/docsify/issues/2093)) ([6a7d15b](https://github.com/docsifyjs/docsify/commit/6a7d15b1d5b93e19d3cf9a328cdbf5f1a166b5bd))
* fix cross-origin links in history router mode ([#1967](https://github.com/docsifyjs/docsify/issues/1967)) ([2312fee](https://github.com/docsifyjs/docsify/commit/2312feef459211a8bcdcbf9164a9ffe051609b70))
* genIndex error for search ([#1933](https://github.com/docsifyjs/docsify/issues/1933)) ([68d8735](https://github.com/docsifyjs/docsify/commit/68d873587c29d694ece466177984aa5fd739dd4b))



# [4.13.0](https://github.com/docsifyjs/docsify/compare/v4.12.4...v4.13.0) (2022-10-26)


### Bug Fixes

* cornerExternalLinkTarget config. ([#1814](https://github.com/docsifyjs/docsify/issues/1814)) ([54cc5f9](https://github.com/docsifyjs/docsify/commit/54cc5f939b9499ae56604f589eef4e3f1c13cdc5))
* correctly fix missing +1, -1 ([#1722](https://github.com/docsifyjs/docsify/issues/1722)) ([719dcbe](https://github.com/docsifyjs/docsify/commit/719dcbea5cb0c8b0835f8e9fc473b094feecb7ec))
* Coverpage when content > viewport height ([#1744](https://github.com/docsifyjs/docsify/issues/1744)) ([301b516](https://github.com/docsifyjs/docsify/commit/301b5169613e95765eda335a4b21d0f9f9cbbbfd)), closes [#381](https://github.com/docsifyjs/docsify/issues/381)
* filter null node first. ([#1909](https://github.com/docsifyjs/docsify/issues/1909)) ([d27af3d](https://github.com/docsifyjs/docsify/commit/d27af3dd09a882fce4f1e2774065de57a3501858))
* fix docsify-ignore in search title. ([#1872](https://github.com/docsifyjs/docsify/issues/1872)) ([9832805](https://github.com/docsifyjs/docsify/commit/9832805681cc6099e9c78deecf6dc0c6fb61fd9b))
* fix search with no content. ([#1878](https://github.com/docsifyjs/docsify/issues/1878)) ([9b74744](https://github.com/docsifyjs/docsify/commit/9b74744299ece0108573a142e5a2e949dc569254))
* Ignore emoji shorthand codes in URIs ([#1847](https://github.com/docsifyjs/docsify/issues/1847)) ([3c9b3d9](https://github.com/docsifyjs/docsify/commit/3c9b3d9702bb05a5ff45a4ce4233e144cf1ebecb)), closes [#1823](https://github.com/docsifyjs/docsify/issues/1823)
* Legacy bugs (styles, site plugin error, and dev server error) ([#1743](https://github.com/docsifyjs/docsify/issues/1743)) ([fa6df6d](https://github.com/docsifyjs/docsify/commit/fa6df6d58487ec294e22be04ac159dfb5745bd66))
* package.json & package-lock.json to reduce vulnerabilities ([#1756](https://github.com/docsifyjs/docsify/issues/1756)) ([2dc5b12](https://github.com/docsifyjs/docsify/commit/2dc5b12b715e3ad1922a6401e3fd9837a99ef9c0))
* packages/docsify-server-renderer/package.json & packages/docsify-server-renderer/package-lock.json to reduce vulnerabilities ([#1715](https://github.com/docsifyjs/docsify/issues/1715)) ([c1227b2](https://github.com/docsifyjs/docsify/commit/c1227b22cb8a3fb6c362ca8ac109082ab2251cc3))


### Features

* Emoji build ([#1766](https://github.com/docsifyjs/docsify/issues/1766)) ([ba5ee26](https://github.com/docsifyjs/docsify/commit/ba5ee26f00e957b58173f96b1901f6ffd3d8e5f5))
* Native emoji w/ image-based fallbacks and improved parsing ([#1746](https://github.com/docsifyjs/docsify/issues/1746)) ([35002c9](https://github.com/docsifyjs/docsify/commit/35002c92b762f0d12e51582d7de7914fa380596a)), closes [#779](https://github.com/docsifyjs/docsify/issues/779)
* Plugin error handling ([#1742](https://github.com/docsifyjs/docsify/issues/1742)) ([63b2535](https://github.com/docsifyjs/docsify/commit/63b2535a45a98945ec897277f4fbddec2ddba887))



## [4.12.2](https://github.com/docsifyjs/docsify/compare/v4.12.1...v4.12.2) (2022-01-06)


### Bug Fixes

* Add escapeHtml for search ([#1551](https://github.com/docsifyjs/docsify/issues/1551)) ([c24f7f6](https://github.com/docsifyjs/docsify/commit/c24f7f6f0b87a87f6dd3755f69eb0969ebb029c9))
* allow also " inside of an embed ([ec16e4a](https://github.com/docsifyjs/docsify/commit/ec16e4a9d5718ac4f4c25bb3dcaea3b7551372e0))
* buble theme missing generic fallback font ([#1568](https://github.com/docsifyjs/docsify/issues/1568)) ([37d9f0e](https://github.com/docsifyjs/docsify/commit/37d9f0e1214276e93b2a11ed87390aafa1bdbcec))
* Cannot read property 'classList' of null ([#1527](https://github.com/docsifyjs/docsify/issues/1527)) ([d6df2b8](https://github.com/docsifyjs/docsify/commit/d6df2b85a99371bb9a87402a10dd515bb734182e))
* Cannot read property 'tagName' of null ([#1655](https://github.com/docsifyjs/docsify/issues/1655)) ([c3cdadc](https://github.com/docsifyjs/docsify/commit/c3cdadc37137edcd9e219359973902d2fc8b66ff))
* upgrade debug from 4.3.2 to 4.3.3 ([#1692](https://github.com/docsifyjs/docsify/issues/1692)) ([40e7749](https://github.com/docsifyjs/docsify/commit/40e77490c68b4143c75dfaebcd0b7f640581306b))
* Upgrade docsify from 4.12.0 to 4.12.1 ([#1544](https://github.com/docsifyjs/docsify/issues/1544)) ([d607f6d](https://github.com/docsifyjs/docsify/commit/d607f6d71c35b50f586806a832f65061f5e3427e))
* upgrade dompurify from 2.2.6 to 2.2.7 ([#1552](https://github.com/docsifyjs/docsify/issues/1552)) ([407e4d4](https://github.com/docsifyjs/docsify/commit/407e4d4f3de78bebd639a3fdae751f8045728e57))
* Upgrade dompurify from 2.2.6 to 2.2.7 ([#1553](https://github.com/docsifyjs/docsify/issues/1553)) ([93c48f3](https://github.com/docsifyjs/docsify/commit/93c48f3d615d95dba550a0e95df6b545d68c3593))
* upgrade dompurify from 2.2.7 to 2.2.8 ([#1577](https://github.com/docsifyjs/docsify/issues/1577)) ([0dd44cc](https://github.com/docsifyjs/docsify/commit/0dd44cc828cc54f7c3b776d45b32925b66cae499))
* upgrade dompurify from 2.2.7 to 2.3.0 ([#1619](https://github.com/docsifyjs/docsify/issues/1619)) ([66303fe](https://github.com/docsifyjs/docsify/commit/66303fec4c7115621e556ad742cfac9d19f26bd9))
* upgrade dompurify from 2.2.8 to 2.2.9 ([#1600](https://github.com/docsifyjs/docsify/issues/1600)) ([baf5a8a](https://github.com/docsifyjs/docsify/commit/baf5a8a4962656d8be8f714283064d2ea10c7e14))
* upgrade dompurify from 2.2.9 to 2.3.0 ([#1616](https://github.com/docsifyjs/docsify/issues/1616)) ([b07fa3c](https://github.com/docsifyjs/docsify/commit/b07fa3cc8323e63dd7b105c7e29b2e1914f5c117))
* upgrade dompurify from 2.3.0 to 2.3.1 ([#1635](https://github.com/docsifyjs/docsify/issues/1635)) ([5ac8237](https://github.com/docsifyjs/docsify/commit/5ac8237cc76e19ca2b373a1a1da6eb4a4da6d8b2))
* upgrade dompurify from 2.3.1 to 2.3.2 ([#1647](https://github.com/docsifyjs/docsify/issues/1647)) ([ff6acfa](https://github.com/docsifyjs/docsify/commit/ff6acfa7623a7db8b00d62c51a9c3037215c4888))
* upgrade node-fetch from 2.6.1 to 2.6.2 ([#1641](https://github.com/docsifyjs/docsify/issues/1641)) ([6ee1c14](https://github.com/docsifyjs/docsify/commit/6ee1c142769a6442aa8c1523ab215106707fa7fc))
* upgrade node-fetch from 2.6.2 to 2.6.4 ([#1649](https://github.com/docsifyjs/docsify/issues/1649)) ([6f81034](https://github.com/docsifyjs/docsify/commit/6f81034ba6a7a6b64ccf1acd2d1fc73761f70a63))
* upgrade node-fetch from 2.6.4 to 2.6.5 ([#1654](https://github.com/docsifyjs/docsify/issues/1654)) ([d16e657](https://github.com/docsifyjs/docsify/commit/d16e657f708777e8377d8e158b50b4010623282d))
* upgrade node-fetch from 2.6.5 to 2.6.6 ([#1668](https://github.com/docsifyjs/docsify/issues/1668)) ([cefe3f8](https://github.com/docsifyjs/docsify/commit/cefe3f87e697a6c54a74d601df2eeb331fcd8933))



## [4.12.1](https://github.com/docsifyjs/docsify/compare/v4.12.0...v4.12.1) (2021-03-07)


### Bug Fixes

* isExternal check with malformed URL + tests ([#1510](https://github.com/docsifyjs/docsify/issues/1510)) ([ff2a66f](https://github.com/docsifyjs/docsify/commit/ff2a66f12752471277fe81a64ad6c4b2c08111fe)), closes [#1477](https://github.com/docsifyjs/docsify/issues/1477) [#1126](https://github.com/docsifyjs/docsify/issues/1126) [#1489](https://github.com/docsifyjs/docsify/issues/1489)
* Replace ES6 usage for IE11 compatibility ([#1500](https://github.com/docsifyjs/docsify/issues/1500)) ([a0f61b2](https://github.com/docsifyjs/docsify/commit/a0f61b2af72cb888ea5b635021a5c9da6beb7ac5))
* theme switcher in IE11 ([#1502](https://github.com/docsifyjs/docsify/issues/1502)) ([8cda078](https://github.com/docsifyjs/docsify/commit/8cda07891afeb1ea6e198d2a600f205357ab4b89))
* Upgrade docsify from 4.11.6 to 4.12.0 ([#1518](https://github.com/docsifyjs/docsify/issues/1518)) ([47cd86c](https://github.com/docsifyjs/docsify/commit/47cd86c8f196a241fc23720e3addfe95d4c973cd))


### Features

* Support search when there is no title ([#1519](https://github.com/docsifyjs/docsify/issues/1519)) ([bc37268](https://github.com/docsifyjs/docsify/commit/bc3726853fb2d1f9241927ea0317970ab0c8a2f2))


### Chore

- Fix missing carbon ([#1501](https://github.com/docsifyjs/docsify/issues/1501))
- Change Gitter to Discord throughout project ([#1507](https://github.com/docsifyjs/docsify/issues/1507))
- Add test cases on isExternal ([#1515](https://github.com/docsifyjs/docsify/issues/1515))


# [4.12.0](https://github.com/docsifyjs/docsify/compare/v4.11.6...v4.12.0) (2021-02-08)


### Bug Fixes

* add missing argument for highlighting code ([#1365](https://github.com/docsifyjs/docsify/issues/1365)) ([f35bf99](https://github.com/docsifyjs/docsify/commit/f35bf99d9c762774e328b30347707e62eb8e6f63))
* Can't search homepage content ([#1391](https://github.com/docsifyjs/docsify/issues/1391)) ([25bc9b7](https://github.com/docsifyjs/docsify/commit/25bc9b7eb7e878a6a50ed5f91d33d6a75f9811b0))
* Cannot read property 'startsWith' of undefined ([#1358](https://github.com/docsifyjs/docsify/issues/1358)) ([9351729](https://github.com/docsifyjs/docsify/commit/9351729634b52db0e7e241bed7784fbcd5c39fe0))
* Cannot read property level of undefined ([#1357](https://github.com/docsifyjs/docsify/issues/1357)) ([4807e58](https://github.com/docsifyjs/docsify/commit/4807e58cb994de83f063cb82d2b4a695f29378c8))
* cannot search list content ([#1361](https://github.com/docsifyjs/docsify/issues/1361)) ([8d17dcb](https://github.com/docsifyjs/docsify/commit/8d17dcbe68048d654e62adb01a3925e39a8e0c44))
* duplicate search content when `/README` or `/` exists in the sidebar ([#1403](https://github.com/docsifyjs/docsify/issues/1403)) ([7c3bf98](https://github.com/docsifyjs/docsify/commit/7c3bf98df869188d5956ed1a331f7048b6eba441))
* package.json & package-lock.json to reduce vulnerabilities ([#1419](https://github.com/docsifyjs/docsify/issues/1419)) ([69b6907](https://github.com/docsifyjs/docsify/commit/69b6907c864dbcdf1fe5c75f51a80e6ae6ec279d))
* packages/docsify-server-renderer/package.json & packages/docsify-server-renderer/package-lock.json to reduce vulnerabilities ([#1389](https://github.com/docsifyjs/docsify/issues/1389)) ([62cd35e](https://github.com/docsifyjs/docsify/commit/62cd35ee8345270aab7a48bc761db007d54a0f48))
* packages/docsify-server-renderer/package.json & packages/docsify-server-renderer/package-lock.json to reduce vulnerabilities ([#1418](https://github.com/docsifyjs/docsify/issues/1418)) ([58fbca0](https://github.com/docsifyjs/docsify/commit/58fbca00ebd12f636c213d386761df9ebfb2bd4c))
* Prevent loading remote content via URL hash ([#1489](https://github.com/docsifyjs/docsify/issues/1489)) ([14ce7f3](https://github.com/docsifyjs/docsify/commit/14ce7f3d862ac79fc7d9d316cb2e057d50e1b506)), closes [#1477](https://github.com/docsifyjs/docsify/issues/1477) [#1126](https://github.com/docsifyjs/docsify/issues/1126)
* search on homepage test ([#1398](https://github.com/docsifyjs/docsify/issues/1398)) ([ee550d0](https://github.com/docsifyjs/docsify/commit/ee550d0c51f222851854c7cd7e9e6f76e26eb6f4))
* search titles containing ignored characters ([#1395](https://github.com/docsifyjs/docsify/issues/1395)) ([a2ebb21](https://github.com/docsifyjs/docsify/commit/a2ebb2192ac73211a8924111d736df9574abf61b))
* sidebar active class and expand don't work as expect when use "space" in markdown filename ([#1454](https://github.com/docsifyjs/docsify/issues/1454)) ([dcf5a64](https://github.com/docsifyjs/docsify/commit/dcf5a644eb6a2eef65fb940f3407c12828a679bc)), closes [#1032](https://github.com/docsifyjs/docsify/issues/1032)
* sidebar horizontal scroll bar ([#1362](https://github.com/docsifyjs/docsify/issues/1362)) ([b480822](https://github.com/docsifyjs/docsify/commit/b480822286c66b478e5a7a9b2c82a10b99c69121))
* sidebar title error ([#1360](https://github.com/docsifyjs/docsify/issues/1360)) ([2100fc3](https://github.com/docsifyjs/docsify/commit/2100fc318b009c6e448e48ffff6a693f1988916c))
* slugs are still broken when headings contain html ([#1443](https://github.com/docsifyjs/docsify/issues/1443)) ([76c5e68](https://github.com/docsifyjs/docsify/commit/76c5e685d75ee6df9acc0a7cf92d5daa138c3240))
* the sidebar links to another site. ([#1336](https://github.com/docsifyjs/docsify/issues/1336)) ([c9d4f7a](https://github.com/docsifyjs/docsify/commit/c9d4f7abc94a2cbc4bb558013775df380c1c8376))
* title error when sidebar link exists with html tag ([#1404](https://github.com/docsifyjs/docsify/issues/1404)) ([8ccc202](https://github.com/docsifyjs/docsify/commit/8ccc20225104376af2e5df6757c4dbd58c0e758e)), closes [#1408](https://github.com/docsifyjs/docsify/issues/1408)
* Unable to navigate on server without default index support ([#1372](https://github.com/docsifyjs/docsify/issues/1372)) ([759ffac](https://github.com/docsifyjs/docsify/commit/759ffac992b19dbb05b92114ec5620d3bb180d0d))
* upgrade debug from 4.1.1 to 4.3.0 ([#1390](https://github.com/docsifyjs/docsify/issues/1390)) ([ae45b32](https://github.com/docsifyjs/docsify/commit/ae45b3201ba03303a2feb5a347b18fda818a569a))
* upgrade debug from 4.3.0 to 4.3.1 ([#1446](https://github.com/docsifyjs/docsify/issues/1446)) ([bc3350f](https://github.com/docsifyjs/docsify/commit/bc3350f6e6bfe670c95569b4e9c51321f5c7dbb9))
* upgrade debug from 4.3.1 to 4.3.2 ([#1463](https://github.com/docsifyjs/docsify/issues/1463)) ([df21153](https://github.com/docsifyjs/docsify/commit/df21153ab5e841ad89707e07c68a04873a2f3fe8))
* upgrade docsify from 4.11.4 to 4.11.6 ([#1373](https://github.com/docsifyjs/docsify/issues/1373)) ([c2d12ed](https://github.com/docsifyjs/docsify/commit/c2d12ed27fe86b0c5cd690b4d8a22bf06d2a90b9))
* upgrade dompurify from 2.0.17 to 2.1.0 ([#1397](https://github.com/docsifyjs/docsify/issues/1397)) ([1863d8e](https://github.com/docsifyjs/docsify/commit/1863d8edb70da234bf7f211986ba71706351682f))
* upgrade dompurify from 2.1.0 to 2.1.1 ([#1402](https://github.com/docsifyjs/docsify/issues/1402)) ([8cf9fd8](https://github.com/docsifyjs/docsify/commit/8cf9fd8150bd67709c68d8dfe4dc881624583ac8))
* upgrade dompurify from 2.2.2 to 2.2.3 ([#1457](https://github.com/docsifyjs/docsify/issues/1457)) ([720d909](https://github.com/docsifyjs/docsify/commit/720d9091c8e571d6c891426983f54d9c94739182))
* upgrade dompurify from 2.2.2 to 2.2.6 ([#1483](https://github.com/docsifyjs/docsify/issues/1483)) ([eee9507](https://github.com/docsifyjs/docsify/commit/eee9507d435459ae8e68e1112bb58a63b2f58530))
* upgrade dompurify from 2.2.3 to 2.2.6 ([#1482](https://github.com/docsifyjs/docsify/issues/1482)) ([7adad57](https://github.com/docsifyjs/docsify/commit/7adad57df1b7efa469b0cde37f788c36dc27cf8b))
* upgrade marked from 1.2.4 to 1.2.9 ([#1486](https://github.com/docsifyjs/docsify/issues/1486)) ([716a7fa](https://github.com/docsifyjs/docsify/commit/716a7fa777a1eee66964977e1d4405cff3275c53))
* upgrade prismjs from 1.21.0 to 1.22.0 ([#1415](https://github.com/docsifyjs/docsify/issues/1415)) ([0806f48](https://github.com/docsifyjs/docsify/commit/0806f48531b6cb5e6a395c12ab88f0b59281bbf8))
* upgrade prismjs from 1.22.0 to 1.23.0 ([#1481](https://github.com/docsifyjs/docsify/issues/1481)) ([5f29cde](https://github.com/docsifyjs/docsify/commit/5f29cde84c7b74d70c34e3f1f43c479f1bba670d))
* Use legacy-compatible methods for IE11 ([#1495](https://github.com/docsifyjs/docsify/issues/1495)) ([06cbebf](https://github.com/docsifyjs/docsify/commit/06cbebfc0d34726f4a7102a7dc9020520f3a7f86))


### Features

* search ignore diacritical marks ([#1434](https://github.com/docsifyjs/docsify/issues/1434)) ([8968a74](https://github.com/docsifyjs/docsify/commit/8968a744cea5910057ba59ef690316722a35b341))
* Add Jest + Playwright Testing ([#1276](https://github.com/docsifyjs/docsify/issues/1276))
* Add Vue components, mount options, global options, and v3 support ([#1409](https://github.com/docsifyjs/docsify/issues/1409))



## [4.11.6](https://github.com/docsifyjs/docsify/compare/v4.11.5...v4.11.6) (2020-08-22)


### Bug Fixes

* Add patch for {docsify-ignore} and {docsify-ignore-all} ([ce31607](https://github.com/docsifyjs/docsify/commit/ce316075e033afdbeb43ce01e284a29fe1870e38))



## [4.11.5](https://github.com/docsifyjs/docsify/compare/v4.11.4...v4.11.5) (2020-08-21)


### Bug Fixes

*  Russian language link error ([#1270](https://github.com/docsifyjs/docsify/issues/1270)) ([2a52460](https://github.com/docsifyjs/docsify/commit/2a52460a59448abaf681046fbc5dca642285ae1f))
* {docsify-updated} in the sample code is parsed into time ([#1321](https://github.com/docsifyjs/docsify/issues/1321)) ([2048610](https://github.com/docsifyjs/docsify/commit/2048610aacd4e3c6a592f4247834a726c7ca33fb))
* Add error handling for missing dependencies (fixes [#1210](https://github.com/docsifyjs/docsify/issues/1210)) ([#1232](https://github.com/docsifyjs/docsify/issues/1232)) ([3673001](https://github.com/docsifyjs/docsify/commit/3673001a24cb24c57454f9bc7619de49d2c3a044))
* after setting the background image, the button is obscured ([#1234](https://github.com/docsifyjs/docsify/issues/1234)) ([34d918f](https://github.com/docsifyjs/docsify/commit/34d918f9973bdb8e893248853e3ef7e803d4c253))
* convert {docsify-ignore} and {docsify-ignore-all} to HTML comments ([#1318](https://github.com/docsifyjs/docsify/issues/1318)) ([90d283d](https://github.com/docsifyjs/docsify/commit/90d283d340502456a5d8495df596bb4a02ceb39b))
* fallback page should use path not file location ([#1301](https://github.com/docsifyjs/docsify/issues/1301)) ([2bceabc](https://github.com/docsifyjs/docsify/commit/2bceabcb8e623570540493e2f1d956adf45c99e7))
* Fix search error when exist translations documents ([#1300](https://github.com/docsifyjs/docsify/issues/1300)) ([b869019](https://github.com/docsifyjs/docsify/commit/b8690199006366e86084e9e018def7b9b8f46512))
* gitignore was ignoring folders in src, so VS Code search results or file fuzzy finder were not working, etc ([d4c9247](https://github.com/docsifyjs/docsify/commit/d4c9247b87c0a2701683ed1a17383cfb451cf609))
* packages/docsify-server-renderer/package.json & packages/docsify-server-renderer/package-lock.json to reduce vulnerabilities ([#1250](https://github.com/docsifyjs/docsify/issues/1250)) ([d439bac](https://github.com/docsifyjs/docsify/commit/d439bac93f479d0480799880538fc3104e54c907))
* search can not search the table header ([#1256](https://github.com/docsifyjs/docsify/issues/1256)) ([3f03e78](https://github.com/docsifyjs/docsify/commit/3f03e78418993d8e9a4f5062e10dc79c3753389e))
* Search plugin: matched text is replaced with search text ([#1298](https://github.com/docsifyjs/docsify/issues/1298)) ([78775b6](https://github.com/docsifyjs/docsify/commit/78775b6ee73102cc5ac71c0ee2b392c5f4f6f4f8))
* the uncaught typeerror when el is null ([#1308](https://github.com/docsifyjs/docsify/issues/1308)) ([952f4c9](https://github.com/docsifyjs/docsify/commit/952f4c921b7a6a558c500ca6b105582d39ad36a2))
* Updated docs with instructions for installing specific version (fixes [#780](https://github.com/docsifyjs/docsify/issues/780)) ([#1225](https://github.com/docsifyjs/docsify/issues/1225)) ([b90c948](https://github.com/docsifyjs/docsify/commit/b90c948090e89fa778279c95060dbd7668285658))
* upgrade medium-zoom from 1.0.5 to 1.0.6 ([3beaa66](https://github.com/docsifyjs/docsify/commit/3beaa6666b78518f1ffaa37f6942f3cb08fef896))
* upgrade tinydate from 1.2.0 to 1.3.0 ([#1341](https://github.com/docsifyjs/docsify/issues/1341)) ([59d090f](https://github.com/docsifyjs/docsify/commit/59d090fe9096bc03e259c166634bb75bb2623f85))


### Features

* **search:** add pathNamespaces option ([d179dde](https://github.com/docsifyjs/docsify/commit/d179dde1c71acdcbe66cb762377b123926c55bf2))
* Add title to sidebar links ([#1286](https://github.com/docsifyjs/docsify/issues/1286)) ([667496b](https://github.com/docsifyjs/docsify/commit/667496b85d99b168255f58e60a6bfe902cc6ee03))



## [4.11.4](https://github.com/docsifyjs/docsify/compare/v4.11.3...v4.11.4) (2020-06-18)


### Bug Fixes

* consistent location of search result ([e9dd2de](https://github.com/docsifyjs/docsify/commit/e9dd2de384b81619aae2bcbf92f52721cb76a177))
* cover overlapping sidebar by removing z-index ([0bf03f5](https://github.com/docsifyjs/docsify/commit/0bf03f58103037d100b1635cf3989c8d3672b4ba))
* cross-origin url cannot be redirected when  "externalLinkTarget" is set to "_self" and "routerMode" is set to "history". ([#1062](https://github.com/docsifyjs/docsify/issues/1062)) ([fd2cec6](https://github.com/docsifyjs/docsify/commit/fd2cec6bd66c46d6957811fefae4c615c3052a4f)), closes [#1046](https://github.com/docsifyjs/docsify/issues/1046) [#1046](https://github.com/docsifyjs/docsify/issues/1046) [#1046](https://github.com/docsifyjs/docsify/issues/1046)
* default html img resize if no height included ([#1065](https://github.com/docsifyjs/docsify/issues/1065)) ([9ff4d06](https://github.com/docsifyjs/docsify/commit/9ff4d0677304bc190e7bd9e89bbbdc64895197fa))
* fixed target and rel issue (fixes [#1183](https://github.com/docsifyjs/docsify/issues/1183)) ([3d662a5](https://github.com/docsifyjs/docsify/commit/3d662a5bf71bbfef077cfbc478df241d794f55a0))
* Inconsistent search and body rendering ([dcb0aae](https://github.com/docsifyjs/docsify/commit/dcb0aaea99efbd68175f1d1aeb5076b6dde9801e))
* rendering cover width bug ([717991c](https://github.com/docsifyjs/docsify/commit/717991c90cf709f4da91fe32610129de6529266b))
* search does not find the contents of the table ([#1198](https://github.com/docsifyjs/docsify/issues/1198)) ([31010e4](https://github.com/docsifyjs/docsify/commit/31010e4979b3d3ab4bd247a09c4ac5fd1405eaa8))
* The search error after setting the ID in the title ([#1159](https://github.com/docsifyjs/docsify/issues/1159)) ([6e554f8](https://github.com/docsifyjs/docsify/commit/6e554f8ebd3d4a2c5c7e4f66cff3dfe2b6aa1e31))
* upgrade docsify from 4.10.2 to 4.11.2 ([60b7f89](https://github.com/docsifyjs/docsify/commit/60b7f89b373b0d48ec8406a51eddeaed8126696d))


### Features

* added html sanitizer for remote rendering ([#1128](https://github.com/docsifyjs/docsify/issues/1128)) ([714ef29](https://github.com/docsifyjs/docsify/commit/714ef29afe779a6db5c4761ebaacdfc70ee2d8dd))
* update src/core/index.js to export all global APIs, deprecate old globals in favor of a single global DOCSIFY, and add tests for this ([7e002bf](https://github.com/docsifyjs/docsify/commit/7e002bf939d7837843908417b5445b4f8d36c1cd))


### Reverts

* Revert "Updated docs site dark and light mode with switch and redesigned search bar using docsify-darklight-theme" (#1207) ([26cb940](https://github.com/docsifyjs/docsify/commit/26cb940b51d34ee584b8425012a336f38a4abd76)), closes [#1207](https://github.com/docsifyjs/docsify/issues/1207) [#1182](https://github.com/docsifyjs/docsify/issues/1182)



## [4.11.3](https://github.com/docsifyjs/docsify/compare/v4.11.2...v4.11.3) (2020-03-24)


### Bug Fixes

* fix: digit issue with sidebar (complete REVERT to old method) ([154abf5](https://github.com/docsifyjs/docsify/commit/154abf59a6153e84b018fcdffa86892776d6da7d))



## [4.11.2](https://github.com/docsifyjs/docsify/compare/v4.11.1...v4.11.2) (2020-03-09)


### Bug Fixes

* fixed rendering of color in coverpage issue ([406670c](https://github.com/docsifyjs/docsify/commit/406670c3d619a627142900fd45019fb8ce00f60a))



## [4.11.1](https://github.com/docsifyjs/docsify/compare/v4.11.0...v4.11.1) (2020-03-09)



# [4.11.0](https://github.com/docsifyjs/docsify/compare/v4.10.2...v4.11.0) (2020-03-09)


### Bug Fixes

* emojis in titles not working correctly and update ([#1016](https://github.com/docsifyjs/docsify/issues/1016)) ([b3d9b96](https://github.com/docsifyjs/docsify/commit/b3d9b966dfbb6f456c2c457da1d2a366e85d9190))
* searching table content ([6184e50](https://github.com/docsifyjs/docsify/commit/6184e502629932ca71fdd0a1b10150d118f5a7c8))
* stage modified files as part of pre-commit hook ([#985](https://github.com/docsifyjs/docsify/issues/985)) ([5b77b0f](https://github.com/docsifyjs/docsify/commit/5b77b0f628f056b7ebb6d0b617561d19964516a2))
* config initialization and coercion ([#861](https://github.com/docsifyjs/docsify/pull/861))
* strip indent when embedding code fragment ([#996](https://github.com/docsifyjs/docsify/pull/996))
* Ensure autoHeader dom result is similar to parsed H1 ([#811](https://github.com/docsifyjs/docsify/pull/811))
* upgrade docsify from 4.9.4 to 4.10.2 ([#1054](https://github.com/docsifyjs/docsify/issues/1054)) ([78290b2](https://github.com/docsifyjs/docsify/commit/78290b21038a3ae09c4c7438bd89b14ca4c02805))
* upgrade medium-zoom from 1.0.4 to 1.0.5 ([39ebd73](https://github.com/docsifyjs/docsify/commit/39ebd73021290439180878cae32e663b9e60e214))
* upgrade prismjs from 1.17.1 to 1.19.0 ([9981c43](https://github.com/docsifyjs/docsify/commit/9981c4361ad690d0ed32cf1fb5b48cc5b9f770bb))


### Features

* configure pre-commit hook ([#983](https://github.com/docsifyjs/docsify/issues/983)) ([eea41a1](https://github.com/docsifyjs/docsify/commit/eea41a1207c46533ea9c6c59d82e2c94aa4dd70e))
* Add a prepare script. ([efbea24](https://github.com/docsifyjs/docsify/commit/efbea24de71f2287993b52ed1cef1a2dd6a53f81))
* added capability to add css class and id to images + links + refactoring ([#820](https://github.com/docsifyjs/docsify/issues/820)) ([724ac02](https://github.com/docsifyjs/docsify/commit/724ac024ddfc28e93d8b5dd909e722747286fa00))
* added dark mode to docs closes [#1031](https://github.com/docsifyjs/docsify/issues/1031) ([dc43d3c](https://github.com/docsifyjs/docsify/commit/dc43d3c512c2f04750e76176c25ece626ae7fe2a))
* new option `hideSidebar` ([#1026](https://github.com/docsifyjs/docsify/issues/1026)) ([b7547f1](https://github.com/docsifyjs/docsify/commit/b7547f151e928b3a0eb6a94b2af36023da4fa877))
* new option `topMargin` ([#1045](https://github.com/docsifyjs/docsify/pull/1045)) ([8faee03](https://github.com/docsifyjs/docsify/pull/1024/commits/b53ea1e304d3a2782b125c1d8711295d88faee03))


### Docs

* update docs for the `name` config option ([#992](https://github.com/docsifyjs/docsify/pull/992))
* about cache ([#854](https://github.com/docsifyjs/docsify/pull/854))
* removed FOSSA badge
* documented `__colon__` tip ([#1025](https://github.com/docsifyjs/docsify/pull/1025))

### Chore

* Migrate relative links to absolute in embedded markdown ([#867](https://github.com/docsifyjs/docsify/pull/867))
* smarter scroll behavior ([#744](https://github.com/docsifyjs/docsify/pull/744))
* improve basic layout style ([#884](https://github.com/docsifyjs/docsify/pull/884))
* There are currently {three=>four} themes available. ([#892](https://github.com/docsifyjs/docsify/pull/892))
* Added a redirect for images to show up in Amplify ([#918](https://github.com/docsifyjs/docsify/pull/918))
* removed the escaping of the name of sidebar ([#991](https://github.com/docsifyjs/docsify/pull/991))
* Eslint fixes for v4x ([#989](https://github.com/docsifyjs/docsify/pull/989))
* added github Actions for CI ([#1000](https://github.com/docsifyjs/docsify/pull/1000))
* Add a prepare script. ([#1010](https://github.com/docsifyjs/docsify/pull/1010))
* chore(GH-action): using ubuntu 16 and removed node 8 from CI
* chore: add config ([#1014](https://github.com/docsifyjs/docsify/pull/1014))
* chore(stale): added enhancement label to exemptlabels
* chore(stale): added bug label to exemptlabels
* .markdown-section max-width 800px to 80% ([#1017](https://github.com/docsifyjs/docsify/pull/1017))
* changed the CDN from unpkg to jsDelivr #1020 ([#1022](https://github.com/docsifyjs/docsify/pull/1022))
* migrate CI to github, refactore CI and npm scripts, linting fixes ([#1023](https://github.com/docsifyjs/docsify/pull/1023))
* chore(readme): added CI badges and fixed the logo issue
* added new linter config ([#1028](https://github.com/docsifyjs/docsify/pull/1028))


## [4.10.2](https://github.com/docsifyjs/docsify/compare/v4.10.0...v4.10.2) (2019-12-16)



# [4.10.0](https://github.com/docsifyjs/docsify/compare/v4.9.4...v4.10.0) (2019-12-16)


### Bug Fixes

* fixed security alert for chokidar(update dep) ([a62b037](https://github.com/docsifyjs/docsify/commit/a62b037becb36941c11c8eab6e4d83df8db85af3))
* npm audit issues ([#934](https://github.com/docsifyjs/docsify/issues/934)) ([615205c](https://github.com/docsifyjs/docsify/commit/615205cfdb7aea8f37a1ec5dd928105eeef56357))
* package security alerts ([f5f1561](https://github.com/docsifyjs/docsify/commit/f5f15619f1a239d6ce12a2f83ad8817352a3352b))
* security alerts of cssnano ([d7d5c8f](https://github.com/docsifyjs/docsify/commit/d7d5c8f302d7c18dbb32e982202a07b73badf6f6))



## [4.9.4](https://github.com/docsifyjs/docsify/compare/v4.9.2...v4.9.4) (2019-05-05)



## [4.9.2](https://github.com/docsifyjs/docsify/compare/v4.9.1...v4.9.2) (2019-04-21)


### Bug Fixes

* re-render gitalk when router changed ([11ea1f8](https://github.com/docsifyjs/docsify/commit/11ea1f8))


### Features

* allows relative path, fixed [#590](https://github.com/docsifyjs/docsify/issues/590) ([31654f1](https://github.com/docsifyjs/docsify/commit/31654f1))



## [4.9.1](https://github.com/docsifyjs/docsify/compare/v4.9.0...v4.9.1) (2019-02-21)


### Bug Fixes

* github assets url ([#774](https://github.com/docsifyjs/docsify/issues/774)) ([140bf10](https://github.com/docsifyjs/docsify/commit/140bf10))



# [4.9.0](https://github.com/docsifyjs/docsify/compare/v4.8.6...v4.9.0) (2019-02-19)


### Bug Fixes

* task list rendering (Fix [#749](https://github.com/docsifyjs/docsify/issues/749)) ([#757](https://github.com/docsifyjs/docsify/issues/757)) ([69ef489](https://github.com/docsifyjs/docsify/commit/69ef489))
* upgrade npm-run-all ([049726e](https://github.com/docsifyjs/docsify/commit/049726e))


### Features

* **search-plugin:** add namespace option ([#706](https://github.com/docsifyjs/docsify/issues/706)) ([28beff8](https://github.com/docsifyjs/docsify/commit/28beff8))
* Add new theme "dolphin" ([#735](https://github.com/docsifyjs/docsify/issues/735)) ([c3345ba](https://github.com/docsifyjs/docsify/commit/c3345ba))
* Provide code fragments feature ([#748](https://github.com/docsifyjs/docsify/issues/748)) ([1447c8a](https://github.com/docsifyjs/docsify/commit/1447c8a))



## [4.8.6](https://github.com/docsifyjs/docsify/compare/v4.8.5...v4.8.6) (2018-11-12)


### Bug Fixes

* IE10 compatibility ([#691](https://github.com/docsifyjs/docsify/issues/691)) ([4db8cd6](https://github.com/docsifyjs/docsify/commit/4db8cd6))



## [4.8.5](https://github.com/docsifyjs/docsify/compare/v4.8.4...v4.8.5) (2018-11-02)


### Bug Fixes

* expose version info for Docsify, fixed [#641](https://github.com/docsifyjs/docsify/issues/641) ([aa719e3](https://github.com/docsifyjs/docsify/commit/aa719e3))



## [4.8.4](https://github.com/docsifyjs/docsify/compare/v4.8.3...v4.8.4) (2018-11-01)


### Bug Fixes

* **cover:** Compatible with legacy styles, fixed [#677](https://github.com/docsifyjs/docsify/issues/677) ([#678](https://github.com/docsifyjs/docsify/issues/678)) ([1a945d4](https://github.com/docsifyjs/docsify/commit/1a945d4))




## [4.8.3](https://github.com/docsifyjs/docsify/compare/v4.8.2...v4.8.3) (2018-11-01)

Fix the last release files has the old version marked...


## [4.8.2](https://github.com/docsifyjs/docsify/compare/v4.8.1...v4.8.2) (2018-11-01)

### Bug Fixes

- cover button style, fixed [#670](https://github.com/docsifyjs/docsify/issues/670), fixed [#665](https://github.com/docsifyjs/docsify/issues/665) ([#675](https://github.com/docsifyjs/docsify/issues/675)) ([fcd1087](https://github.com/docsifyjs/docsify/commit/fcd1087))
- update match regex ([#669](https://github.com/docsifyjs/docsify/issues/669)) ([2edf47e](https://github.com/docsifyjs/docsify/commit/2edf47e))
- use copy of cached value ([#668](https://github.com/docsifyjs/docsify/issues/668)) ([5fcf210](https://github.com/docsifyjs/docsify/commit/5fcf210))
- **compiler:** import prism-markup-templating, fixed [#672](https://github.com/docsifyjs/docsify/issues/672) ([#676](https://github.com/docsifyjs/docsify/issues/676)) ([fdd8826](https://github.com/docsifyjs/docsify/commit/fdd8826))

### Features

- add heading config id ([#671](https://github.com/docsifyjs/docsify/issues/671)) ([ab19b13](https://github.com/docsifyjs/docsify/commit/ab19b13))


## [4.8.1](https://github.com/docsifyjs/docsify/compare/v4.8.0...v4.8.1) (2018-10-31)

### Bug Fixes

- ssr package dep, fixed [#605](https://github.com/docsifyjs/docsify/issues/605) ([2bc880d](https://github.com/docsifyjs/docsify/commit/2bc880d))
- **compiler:** extra quotes for codeblock ([4f588e0](https://github.com/docsifyjs/docsify/commit/4f588e0))
- **compiler:** prevent render of html code in paragraph, fixed [#663](https://github.com/docsifyjs/docsify/issues/663) ([d35059d](https://github.com/docsifyjs/docsify/commit/d35059d))

### Features

- upgrade PrismJS, fixed [#534](https://github.com/docsifyjs/docsify/issues/534) ([4805cb5](https://github.com/docsifyjs/docsify/commit/4805cb5))


# [4.8.0](https://github.com/docsifyjs/docsify/compare/v4.7.1...v4.8.0) (2018-10-31)

### Bug Fixes

- Cache TOC for later usage in the case of cached file html ([#649](https://github.com/docsifyjs/docsify/issues/649)) ([9e86017](https://github.com/docsifyjs/docsify/commit/9e86017))
- improve external script plugin ([#632](https://github.com/docsifyjs/docsify/issues/632)) ([50c2434](https://github.com/docsifyjs/docsify/commit/50c2434))
- missing variable declaration ([#660](https://github.com/docsifyjs/docsify/issues/660)) ([1ce37bd](https://github.com/docsifyjs/docsify/commit/1ce37bd))
- Remove target for mailto links ([#652](https://github.com/docsifyjs/docsify/issues/652)) ([18f0f03](https://github.com/docsifyjs/docsify/commit/18f0f03))
- Update getAllPath query selector ([#653](https://github.com/docsifyjs/docsify/issues/653)) ([f6f4e32](https://github.com/docsifyjs/docsify/commit/f6f4e32))
- Update vue.styl ([#634](https://github.com/docsifyjs/docsify/issues/634)) ([bf060be](https://github.com/docsifyjs/docsify/commit/bf060be))

### Features

- Add docsify version to $window.docsify object ([#641](https://github.com/docsifyjs/docsify/issues/641)) ([94bc415](https://github.com/docsifyjs/docsify/commit/94bc415)), closes [#521](https://github.com/docsifyjs/docsify/issues/521)
- **compiler:** support embedded mermaid ([#629](https://github.com/docsifyjs/docsify/issues/629)) ([42ea8af](https://github.com/docsifyjs/docsify/commit/42ea8af))
- Add hideOtherSidebarContent option ([#661](https://github.com/docsifyjs/docsify/issues/661)) ([4a23c4a](https://github.com/docsifyjs/docsify/commit/4a23c4a))
- Allow base64, external, and relative logo values ([#642](https://github.com/docsifyjs/docsify/issues/642)) ([0a0802a](https://github.com/docsifyjs/docsify/commit/0a0802a)), closes [#577](https://github.com/docsifyjs/docsify/issues/577)
- upgrade marked to 0.5.x, fixed [#645](https://github.com/docsifyjs/docsify/issues/645), close [#644](https://github.com/docsifyjs/docsify/issues/644) ([#662](https://github.com/docsifyjs/docsify/issues/662)) ([a39b214](https://github.com/docsifyjs/docsify/commit/a39b214))


## [4.7.1](https://github.com/docsifyjs/docsify/compare/v4.7.0...v4.7.1) (2018-08-30)


# [4.7.0](https://github.com/QingWei-Li/docsify/compare/v4.6.9...v4.7.0) (2018-06-29)

### Bug Fixes

- alldow addition content in sidebar, fix [#518](https://github.com/QingWei-Li/docsify/issues/518), fix 539 ([#543](https://github.com/QingWei-Li/docsify/issues/543)) ([04b36b0](https://github.com/QingWei-Li/docsify/commit/04b36b0))
- async install config, fixed [#425](https://github.com/QingWei-Li/docsify/issues/425) ([e4e011c](https://github.com/QingWei-Li/docsify/commit/e4e011c))
- loading embed files synchronously, fixed [#525](https://github.com/QingWei-Li/docsify/issues/525), fixed [#527](https://github.com/QingWei-Li/docsify/issues/527) ([#544](https://github.com/QingWei-Li/docsify/issues/544)) ([feea7f9](https://github.com/QingWei-Li/docsify/commit/feea7f9))
- path include chinese character cause hilight bug ([#556](https://github.com/QingWei-Li/docsify/issues/556)) ([a5f333a](https://github.com/QingWei-Li/docsify/commit/a5f333a))

### Features

- add logo option, [#264](https://github.com/QingWei-Li/docsify/issues/264) ([#541](https://github.com/QingWei-Li/docsify/issues/541)) ([ee72dd0](https://github.com/QingWei-Li/docsify/commit/ee72dd0))
- add unpkg field, close [#531](https://github.com/QingWei-Li/docsify/issues/531) ([#558](https://github.com/QingWei-Li/docsify/issues/558)) ([5c0de0a](https://github.com/QingWei-Li/docsify/commit/5c0de0a))
- support image resizing, resolve [#508](https://github.com/QingWei-Li/docsify/issues/508) ([#545](https://github.com/QingWei-Li/docsify/issues/545)) ([3a7ad62](https://github.com/QingWei-Li/docsify/commit/3a7ad62))


## [4.6.10](https://github.com/QingWei-Li/docsify/compare/v4.6.9...v4.6.10) (2018-03-25)

### Bug Fixes

- async install config, fixed [#425](https://github.com/QingWei-Li/docsify/issues/425) ([e4e011c](https://github.com/QingWei-Li/docsify/commit/e4e011c))


## [4.6.9](https://github.com/QingWei-Li/docsify/compare/v4.6.8...v4.6.9) (2018-03-10)

### Bug Fixes

- upgrade medium-zoom, fixed [#417](https://github.com/QingWei-Li/docsify/issues/417) ([6a3d69a](https://github.com/QingWei-Li/docsify/commit/6a3d69a))


## [4.6.8](https://github.com/QingWei-Li/docsify/compare/v4.6.7...v4.6.8) (2018-03-06)

### Bug Fixes

- resolve path of image and embed files, fixed [#412](https://github.com/QingWei-Li/docsify/issues/412) ([bfd0d18](https://github.com/QingWei-Li/docsify/commit/bfd0d18))


## [4.6.7](https://github.com/QingWei-Li/docsify/compare/v4.6.6...v4.6.7) (2018-03-03)

### Bug Fixes

- layout css, fixed [#409](https://github.com/QingWei-Li/docsify/issues/409) ([aeb692e](https://github.com/QingWei-Li/docsify/commit/aeb692e))


## [4.6.6](https://github.com/QingWei-Li/docsify/compare/v4.6.5...v4.6.6) (2018-03-03)


## [4.6.5](https://github.com/QingWei-Li/docsify/compare/v4.6.4...v4.6.5) (2018-03-03)

### Bug Fixes

- **navbar:** Now Navbar isn't append to DOM when loadNavbar is falsy ([#407](https://github.com/QingWei-Li/docsify/issues/407)) ([0933445](https://github.com/QingWei-Li/docsify/commit/0933445))

### Features

- **config:** Add 404 page options. ([#406](https://github.com/QingWei-Li/docsify/issues/406)) ([9b3b445](https://github.com/QingWei-Li/docsify/commit/9b3b445))


## [4.6.4](https://github.com/QingWei-Li/docsify/compare/v4.6.3...v4.6.4) (2018-03-01)

### Bug Fixes

- **render:** Disable markdown parsing when the file is an HTML ([#403](https://github.com/QingWei-Li/docsify/issues/403)) ([278a75e](https://github.com/QingWei-Li/docsify/commit/278a75e))

### Features

- **fetch:** Add fallback languages configuration. ([#402](https://github.com/QingWei-Li/docsify/issues/402)) ([ecc0e04](https://github.com/QingWei-Li/docsify/commit/ecc0e04))


## [4.6.3](https://github.com/QingWei-Li/docsify/compare/v4.6.2...v4.6.3) (2018-02-15)

### Bug Fixes

- **hook:** beforeEach don\'t work, fixed [#393](https://github.com/QingWei-Li/docsify/issues/393) ([6a09059](https://github.com/QingWei-Li/docsify/commit/6a09059))


## [4.6.2](https://github.com/QingWei-Li/docsify/compare/v4.6.1...v4.6.2) (2018-02-14)

### Bug Fixes

- **embed:** broken in IE, fixed [#389](https://github.com/QingWei-Li/docsify/issues/389), fixed [#391](https://github.com/QingWei-Li/docsify/issues/391) ([45a7464](https://github.com/QingWei-Li/docsify/commit/45a7464))
- **embed:** init value ([890a7bf](https://github.com/QingWei-Li/docsify/commit/890a7bf))


## [4.6.1](https://github.com/QingWei-Li/docsify/compare/v4.6.0...v4.6.1) (2018-02-12)

### Bug Fixes

- **embed** compatible ssr ([dc0c3ce](https://github.com/QingWei-Li/docsify/commit/dc0c3ce))
- **embed** async fetch embed files, fixed [#387](https://github.com/QingWei-Li/docsify/issues/387)


# [4.6.0](https://github.com/QingWei-Li/docsify/compare/v4.5.9...v4.6.0) (2018-02-11)

### Bug Fixes

- **search:** custom clear button, fixed [#271](https://github.com/QingWei-Li/docsify/issues/271) ([864aa18](https://github.com/QingWei-Li/docsify/commit/864aa18))
- **search:** escape special characters for search, fixed [#369](https://github.com/QingWei-Li/docsify/issues/369) ([9755439](https://github.com/QingWei-Li/docsify/commit/9755439))
- build config ([342438f](https://github.com/QingWei-Li/docsify/commit/342438f))
- button style for coverpage, fixed [#362](https://github.com/QingWei-Li/docsify/issues/362) ([85428ef](https://github.com/QingWei-Li/docsify/commit/85428ef))
- dropdown scroll style, fixed [#346](https://github.com/QingWei-Li/docsify/issues/346) ([c4d83f2](https://github.com/QingWei-Li/docsify/commit/c4d83f2))
- highlight homepage link, fixed [#304](https://github.com/QingWei-Li/docsify/issues/304) ([f960c19](https://github.com/QingWei-Li/docsify/commit/f960c19))
- homepage link ([e097f88](https://github.com/QingWei-Li/docsify/commit/e097f88))
- onlyCover ([033be4f](https://github.com/QingWei-Li/docsify/commit/033be4f))
- ssr compatible embedd ([ebc10c4](https://github.com/QingWei-Li/docsify/commit/ebc10c4))
- ssr coverpage, fixed [#273](https://github.com/QingWei-Li/docsify/issues/273) ([9e824a4](https://github.com/QingWei-Li/docsify/commit/9e824a4))

### Features

- click sidebar menu add collapse and expand, close [#294](https://github.com/QingWei-Li/docsify/issues/294) ([5e161a1](https://github.com/QingWei-Li/docsify/commit/5e161a1))
- **compiler:** support embedded file as code block, close [#134](https://github.com/QingWei-Li/docsify/issues/134) ([761ccc2](https://github.com/QingWei-Li/docsify/commit/761ccc2))
- **compiler:** support embedded markdown, html, video, etc files, close [#383](https://github.com/QingWei-Li/docsify/issues/383), close [#333](https://github.com/QingWei-Li/docsify/issues/333) ([524f52f](https://github.com/QingWei-Li/docsify/commit/524f52f))
- **cover:** add onlyCover option, close [#382](https://github.com/QingWei-Li/docsify/issues/382) ([b265fdd](https://github.com/QingWei-Li/docsify/commit/b265fdd))
- **fetch:** add requestHeaders option, fixed [#336](https://github.com/QingWei-Li/docsify/issues/336) ([54ab4c9](https://github.com/QingWei-Li/docsify/commit/54ab4c9))
- **render:** add ext option for custom file extension, close [#340](https://github.com/QingWei-Li/docsify/issues/340) ([248aa72](https://github.com/QingWei-Li/docsify/commit/248aa72))
- **render:** mutilple coverpage, close [#315](https://github.com/QingWei-Li/docsify/issues/315) ([f68ddf5](https://github.com/QingWei-Li/docsify/commit/f68ddf5))


## [4.5.9](https://github.com/QingWei-Li/docsify/compare/v4.5.8...v4.5.9) (2018-02-07)

### Bug Fixes

- upgrade marked ([4157173](https://github.com/QingWei-Li/docsify/commit/4157173))


## [4.5.8](https://github.com/QingWei-Li/docsify/compare/v4.5.6...v4.5.8) (2018-02-07)

### Bug Fixes

- cover style, fixed [#381](https://github.com/QingWei-Li/docsify/issues/381) ([368754e](https://github.com/QingWei-Li/docsify/commit/368754e))
- updated deps ([#337](https://github.com/QingWei-Li/docsify/issues/337)) ([a12d393](https://github.com/QingWei-Li/docsify/commit/a12d393))


## [4.5.7](https://github.com/QingWei-Li/docsify/compare/v4.5.6...v4.5.7) (2017-12-29)

### Features

- add navigation plugin, closed [#180](https://github.com/QingWei-Li/docsify/issues/180) ([f78be4c](https://github.com/QingWei-Li/docsify/commit/f78be4c))


## [4.5.6](https://github.com/QingWei-Li/docsify/compare/v4.5.3...v4.5.6) (2017-12-14)

### Bug Fixes

- **style:** increase the tap targets of menu button, fixed [#325](https://github.com/QingWei-Li/docsify/issues/325) ([888f217](https://github.com/QingWei-Li/docsify/commit/888f217))


## [4.5.5](https://github.com/QingWei-Li/docsify/compare/v4.5.4...v4.5.5) (2017-11-30)

### Bug Fixes

- disqus plugin issue ([#318](https://github.com/QingWei-Li/docsify/issues/318)) ([041b33e](https://github.com/QingWei-Li/docsify/commit/041b33e)), closes [#317](https://github.com/QingWei-Li/docsify/issues/317)


## [4.5.4](https://github.com/QingWei-Li/docsify/compare/v4.5.2...v4.5.4) (2017-11-29)

### Bug Fixes

- **compiler:** task lists style, fixed [#215](https://github.com/QingWei-Li/docsify/issues/215) ([e43ded4](https://github.com/QingWei-Li/docsify/commit/e43ded4))

### Features

- add gitalk plugin ([#306](https://github.com/QingWei-Li/docsify/issues/306)) ([9208e64](https://github.com/QingWei-Li/docsify/commit/9208e64))


## [4.5.3](https://github.com/QingWei-Li/docsify/compare/v4.5.2...v4.5.3) (2017-11-11)

### Features

- add gitalk plugin ([#306](https://github.com/QingWei-Li/docsify/issues/306)) ([9208e64](https://github.com/QingWei-Li/docsify/commit/9208e64))


## [4.5.2](https://github.com/QingWei-Li/docsify/compare/v4.5.1...v4.5.2) (2017-11-09)

### Features

- github task lists, close [#215](https://github.com/QingWei-Li/docsify/issues/215) ([#305](https://github.com/QingWei-Li/docsify/issues/305)) ([d486eef](https://github.com/QingWei-Li/docsify/commit/d486eef))


## [4.5.1](https://github.com/QingWei-Li/docsify/compare/v4.5.0...v4.5.1) (2017-11-07)

### Features

- fetch files with the query params, fixed [#303](https://github.com/QingWei-Li/docsify/issues/303) ([2a2ed96](https://github.com/QingWei-Li/docsify/commit/2a2ed96))


# [4.5.0](https://github.com/QingWei-Li/docsify/compare/v4.4.1...v4.5.0) (2017-11-04)

### Features

- add disqus plugin, closed [#123](https://github.com/QingWei-Li/docsify/issues/123) ([fd7d4e0](https://github.com/QingWei-Li/docsify/commit/fd7d4e0))


## [4.4.1](https://github.com/QingWei-Li/docsify/compare/v4.4.0...v4.4.1) (2017-10-31)

### Bug Fixes

- {docsify-ignore-all} and {docsify-ignore} bug ([#299](https://github.com/QingWei-Li/docsify/issues/299)) ([cc98f56](https://github.com/QingWei-Li/docsify/commit/cc98f56))
- zoom image plugin issue, fixed [#187](https://github.com/QingWei-Li/docsify/issues/187) ([#300](https://github.com/QingWei-Li/docsify/issues/300)) ([fa772cf](https://github.com/QingWei-Li/docsify/commit/fa772cf))


# [4.4.0](https://github.com/QingWei-Li/docsify/compare/v4.3.15...v4.4.0) (2017-10-30)

### Bug Fixes

- sidebar style issue on firefox, fixed [#184](https://github.com/QingWei-Li/docsify/issues/184) ([#297](https://github.com/QingWei-Li/docsify/issues/297)) ([36bfc9d](https://github.com/QingWei-Li/docsify/commit/36bfc9d))

### Features

- add helper for disabled link, fixed [#295](https://github.com/QingWei-Li/docsify/issues/295) ([#296](https://github.com/QingWei-Li/docsify/issues/296)) ([4ad96f3](https://github.com/QingWei-Li/docsify/commit/4ad96f3))


## [4.3.15](https://github.com/QingWei-Li/docsify/compare/v4.3.14...v4.3.15) (2017-10-20)

### Bug Fixes

- scroll active sidebar ([a2b8eae](https://github.com/QingWei-Li/docsify/commit/a2b8eae))


## [4.3.14](https://github.com/QingWei-Li/docsify/compare/v4.3.13...v4.3.14) (2017-10-20)

### Bug Fixes

- codesponsor style ([ab68268](https://github.com/QingWei-Li/docsify/commit/ab68268))


## [4.3.13](https://github.com/QingWei-Li/docsify/compare/v4.3.12...v4.3.13) (2017-10-17)

### Bug Fixes

- duplicate results in search fixed [#257](https://github.com/QingWei-Li/docsify/issues/257) ([#284](https://github.com/QingWei-Li/docsify/issues/284)) ([3476f6f](https://github.com/QingWei-Li/docsify/commit/3476f6f))

### Features

- make whole search result clickable ([#285](https://github.com/QingWei-Li/docsify/issues/285)) ([1b91227](https://github.com/QingWei-Li/docsify/commit/1b91227))


## [4.3.12](https://github.com/QingWei-Li/docsify/compare/v4.3.11...v4.3.12) (2017-10-15)

### Bug Fixes

- incorrect active link ([#281](https://github.com/QingWei-Li/docsify/issues/281)) ([a3ab379](https://github.com/QingWei-Li/docsify/commit/a3ab379))


## [4.3.11](https://github.com/QingWei-Li/docsify/compare/v4.3.10...v4.3.11) (2017-10-15)

### Bug Fixes

- broken links to same page heading, fix [#278](https://github.com/QingWei-Li/docsify/issues/278), fix [#279](https://github.com/QingWei-Li/docsify/issues/279) ([91d6337](https://github.com/QingWei-Li/docsify/commit/91d6337))


## [4.3.10](https://github.com/QingWei-Li/docsify/compare/v4.3.9...v4.3.10) (2017-10-12)

### Bug Fixes

- link render issue after page refreshing ([#276](https://github.com/QingWei-Li/docsify/issues/276)) ([abd885e](https://github.com/QingWei-Li/docsify/commit/abd885e))


## [4.3.9](https://github.com/QingWei-Li/docsify/compare/v4.3.8...v4.3.9) (2017-10-11)

### Bug Fixes

- scroll issue in IE ([#275](https://github.com/QingWei-Li/docsify/issues/275)) ([3e94cb6](https://github.com/QingWei-Li/docsify/commit/3e94cb6))


## [4.3.8](https://github.com/QingWei-Li/docsify/compare/v4.3.7...v4.3.8) (2017-10-07)

### Bug Fixes

- **slugify:** GitHub compatible heading links, fixed [#272](https://github.com/QingWei-Li/docsify/issues/272) ([9b4e666](https://github.com/QingWei-Li/docsify/commit/9b4e666))


## [4.3.7](https://github.com/QingWei-Li/docsify/compare/v4.3.6...v4.3.7) (2017-10-02)

### Bug Fixes

- **slugify:** GitHub compatible heading links, fixed [#267](https://github.com/QingWei-Li/docsify/issues/267) ([c195d2d](https://github.com/QingWei-Li/docsify/commit/c195d2d))


## [4.3.6](https://github.com/QingWei-Li/docsify/compare/v4.3.5...v4.3.6) (2017-09-21)

### Bug Fixes

- style for codesponsor plugin ([08afec7](https://github.com/QingWei-Li/docsify/commit/08afec7))


## [4.3.5](https://github.com/QingWei-Li/docsify/compare/v4.3.4...v4.3.5) (2017-09-20)

### Bug Fixes

- missed symbol ([#254](https://github.com/QingWei-Li/docsify/issues/254)) ([6c702d3](https://github.com/QingWei-Li/docsify/commit/6c702d3))

### Features

- **plugin:** add codesponsor plugin ([46ac4c3](https://github.com/QingWei-Li/docsify/commit/46ac4c3))


## [4.3.4](https://github.com/QingWei-Li/docsify/compare/v4.3.3...v4.3.4) (2017-09-07)

### Bug Fixes

- scroll position issue, fixed [#234](https://github.com/QingWei-Li/docsify/issues/234) ([388ed3d](https://github.com/QingWei-Li/docsify/commit/388ed3d))


## [4.3.3](https://github.com/QingWei-Li/docsify/compare/v4.3.2...v4.3.3) (2017-09-06)

### Bug Fixes

- **buble.css:** tweaks code block style, fixed [#249](https://github.com/QingWei-Li/docsify/issues/249) ([9d43051](https://github.com/QingWei-Li/docsify/commit/9d43051))

### Features

- add doc for react and vue demo box plugin ([#247](https://github.com/QingWei-Li/docsify/issues/247)) ([f0aca19](https://github.com/QingWei-Li/docsify/commit/f0aca19))


## [4.3.2](https://github.com/QingWei-Li/docsify/compare/v4.3.1...v4.3.2) (2017-09-01)

### Bug Fixes

- sidebar highlight ([f82f419](https://github.com/QingWei-Li/docsify/commit/f82f419))

### Features

- add Edit on github plugin (thanks [@njleonzhang](https://github.com/njleonzhang)) ([a0e1ea8](https://github.com/QingWei-Li/docsify/commit/a0e1ea8))


## [4.3.1](https://github.com/QingWei-Li/docsify/compare/v4.2.9...v4.3.1) (2017-08-30)

### Features

- **markdown:** supports mermaid [#137](https://github.com/QingWei-Li/docsify/issues/137) ([f4800e0](https://github.com/QingWei-Li/docsify/commit/f4800e0))


# [4.3.0](https://github.com/QingWei-Li/docsify/compare/v4.2.9...v4.3.0) (2017-08-17)

### Features

- **markdown:** supports mermaid [#137](https://github.com/QingWei-Li/docsify/issues/137) ([f4800e0](https://github.com/QingWei-Li/docsify/commit/f4800e0))


## [4.2.9](https://github.com/QingWei-Li/docsify/compare/v4.2.8...v4.2.9) (2017-08-15)

### Bug Fixes

- ensure document ready before init Docsify [#233](https://github.com/QingWei-Li/docsify/issues/233)


## [4.2.8](https://github.com/QingWei-Li/docsify/compare/v4.2.7...v4.2.8) (2017-08-10)

### Features

- **compiler:** support for setting target attribute for link, fixed [#230](https://github.com/QingWei-Li/docsify/issues/230) ([7f270f9](https://github.com/QingWei-Li/docsify/commit/7f270f9))


## [4.2.7](https://github.com/QingWei-Li/docsify/compare/v4.2.4...v4.2.7) (2017-08-05)

### Bug Fixes

- **release:** release shell ([628e211](https://github.com/QingWei-Li/docsify/commit/628e211))
- **style:** nowrap => pre-wrap, fixed [#228](https://github.com/QingWei-Li/docsify/issues/228) ([a88252c](https://github.com/QingWei-Li/docsify/commit/a88252c))


## [4.2.6](https://github.com/QingWei-Li/docsify/compare/v4.2.4...v4.2.6) (2017-07-27)

### Bug Fixes

- **css:** hide the nav when the content has not yet been loaded ([1fa1619](https://github.com/QingWei-Li/docsify/commit/1fa1619))
- **release:** release shell ([628e211](https://github.com/QingWei-Li/docsify/commit/628e211))


## [4.2.4](https://github.com/QingWei-Li/docsify/compare/v4.2.2...v4.2.4) (2017-07-26)

### Bug Fixes

- **render:** Remove getRootNode to be compatible with the lower version of Chrome, fixed [#225](https://github.com/QingWei-Li/docsify/issues/225) ([b8dd346](https://github.com/QingWei-Li/docsify/commit/b8dd346))


## [4.2.3](https://github.com/QingWei-Li/docsify/compare/v4.2.2...v4.2.3) (2017-07-26)

### Features

- **search:** Supports the max depth of the search headline, fixed [#223](https://github.com/QingWei-Li/docsify/issues/223), resolve [#129](https://github.com/QingWei-Li/docsify/issues/129) ([b7b589b](https://github.com/QingWei-Li/docsify/commit/b7b589b))


## [4.2.2](https://github.com/QingWei-Li/docsify/compare/v4.2.1...v4.2.2) (2017-07-24)

### Bug Fixes

- style rerender due to setting themeColor ([17ff3d1](https://github.com/QingWei-Li/docsify/commit/17ff3d1))


## [4.2.1](https://github.com/QingWei-Li/docsify/compare/v4.2.0...v4.2.1) (2017-07-19)

- give the navbar some line-height (#216)
- Remove unnecessary moduleName option from rollup config for plugins (#209)


# [4.2.0](https://github.com/QingWei-Li/docsify/compare/v4.1.14...v4.2.0) (2017-07-10)

### Bug Fixes

- not found page ([9af8559](https://github.com/QingWei-Li/docsify/commit/9af8559))

### Features

- alias option supports regexp, resolve [#183](https://github.com/QingWei-Li/docsify/issues/183) ([c4aa22c](https://github.com/QingWei-Li/docsify/commit/c4aa22c))
- ignore to compiled link, fixed [#203](https://github.com/QingWei-Li/docsify/issues/203) ([#204](https://github.com/QingWei-Li/docsify/issues/204)) ([2e00f4c](https://github.com/QingWei-Li/docsify/commit/2e00f4c))


## [4.1.14](https://github.com/QingWei-Li/docsify/compare/v4.1.13...v4.1.14) (2017-06-24)

### Bug Fixes

- get file path ([e8117e5](https://github.com/QingWei-Li/docsify/commit/e8117e5))

### Features

- add context attribute, fixed [#191](https://github.com/QingWei-Li/docsify/issues/191) ([ce0e9ac](https://github.com/QingWei-Li/docsify/commit/ce0e9ac))


## [4.1.13](https://github.com/QingWei-Li/docsify/compare/v4.1.12...v4.1.13) (2017-06-11)


## [4.1.12](https://github.com/QingWei-Li/docsify/compare/v4.1.11...v4.1.12) (2017-06-03)

### Bug Fixes

- **render:** subtitle in side bar shows undefined, fixed [#182](https://github.com/QingWei-Li/docsify/issues/182) ([d087d57](https://github.com/QingWei-Li/docsify/commit/d087d57))


## [4.1.11](https://github.com/QingWei-Li/docsify/compare/v4.1.10...v4.1.11) (2017-06-02)

### Bug Fixes

- **compiler:** force reset toc when rendering sidebar fixed [#181](https://github.com/QingWei-Li/docsify/issues/181) ([ccf4c7c](https://github.com/QingWei-Li/docsify/commit/ccf4c7c))
- **render:** autoHeader does not work ([1304d2e](https://github.com/QingWei-Li/docsify/commit/1304d2e))


## [4.1.10](https://github.com/QingWei-Li/docsify/compare/v4.1.9...v4.1.10) (2017-06-02)

### Bug Fixes

- **hash:** hash routing crashes when url has querystring ([6d48ce1](https://github.com/QingWei-Li/docsify/commit/6d48ce1))


## [4.1.9](https://github.com/QingWei-Li/docsify/compare/v4.1.8...v4.1.9) (2017-05-31)

### Bug Fixes

- can't render toc on first load ([d9b487e](https://github.com/QingWei-Li/docsify/commit/d9b487e))
- **lifecycle:** continue to handle data ([955d3d5](https://github.com/QingWei-Li/docsify/commit/955d3d5))
- **render:** broken name link, fixed [#167](https://github.com/QingWei-Li/docsify/issues/167) ([91b66a5](https://github.com/QingWei-Li/docsify/commit/91b66a5))


## [4.1.8](https://github.com/QingWei-Li/docsify/compare/v4.1.7...v4.1.8) (2017-05-31)

### Bug Fixes

- auto replace version ([22b50f0](https://github.com/QingWei-Li/docsify/commit/22b50f0))
- update edit button demo ([ec887c1](https://github.com/QingWei-Li/docsify/commit/ec887c1))

### Features

- add edit button demo ([a64cee1](https://github.com/QingWei-Li/docsify/commit/a64cee1))
- add edit button demo, close [#162](https://github.com/QingWei-Li/docsify/issues/162) ([036fdac](https://github.com/QingWei-Li/docsify/commit/036fdac))

## [4.1.7](https://github.com/QingWei-Li/docsify/compare/v4.1.6...v4.1.7) (2017-05-30)

### Bug Fixes

- **ssr:** clean files ([0014895](https://github.com/QingWei-Li/docsify/commit/0014895))

## [4.1.6](https://github.com/QingWei-Li/docsify/compare/v4.1.5...v4.1.6) (2017-05-30)

### Bug Fixes

- **ssr:** add debug ([6b9e092](https://github.com/QingWei-Li/docsify/commit/6b9e092))

## [4.1.5](https://github.com/QingWei-Li/docsify/compare/v4.1.4...v4.1.5) (2017-05-30)

### Bug Fixes

- **ssr:** missing package ([6db8c9e](https://github.com/QingWei-Li/docsify/commit/6db8c9e))

## [4.1.4](https://github.com/QingWei-Li/docsify/compare/v4.1.3...v4.1.4) (2017-05-30)

### Bug Fixes

- **ssr:** file path ([79a83bc](https://github.com/QingWei-Li/docsify/commit/79a83bc))

## [4.1.3](https://github.com/QingWei-Li/docsify/compare/v4.1.2...v4.1.3) (2017-05-30)

### Bug Fixes

- update babel config ([9825db4](https://github.com/QingWei-Li/docsify/commit/9825db4))

## [4.1.2](https://github.com/QingWei-Li/docsify/compare/v4.1.1...v4.1.2) (2017-05-30)

### Bug Fixes

- update babel config ([80dba19](https://github.com/QingWei-Li/docsify/commit/80dba19))

## [4.1.1](https://github.com/QingWei-Li/docsify/compare/v4.1.0...v4.1.1) (2017-05-30)

### Bug Fixes

- build for ssr package ([4cb20a5](https://github.com/QingWei-Li/docsify/commit/4cb20a5))
- remove history mode ([0e74e6c](https://github.com/QingWei-Li/docsify/commit/0e74e6c))

# [4.1.0](https://github.com/QingWei-Li/docsify/compare/v4.0.2...v4.1.0) (2017-05-30)

## [4.0.2](https://github.com/QingWei-Li/docsify/compare/v4.0.1...v4.0.2) (2017-05-30)

### Bug Fixes

- basePath for history mode ([fc1cd3f](https://github.com/QingWei-Li/docsify/commit/fc1cd3f))

## [4.0.1](https://github.com/QingWei-Li/docsify/compare/v4.0.0...v4.0.1) (2017-05-29)

### Bug Fixes

- **ssr:** remove context ([4626157](https://github.com/QingWei-Li/docsify/commit/4626157))
- lint ([b764b6e](https://github.com/QingWei-Li/docsify/commit/b764b6e))

# [4.0.0](https://github.com/QingWei-Li/docsify/compare/v3.7.3...v4.0.0) (2017-05-29)

### Bug Fixes

- **render:** init event in ssr ([eba1c98](https://github.com/QingWei-Li/docsify/commit/eba1c98))
- lint ([1f4514d](https://github.com/QingWei-Li/docsify/commit/1f4514d))

### Features

- finish ssr ([3444884](https://github.com/QingWei-Li/docsify/commit/3444884))
- init docsify-server-renderer ([6dea685](https://github.com/QingWei-Li/docsify/commit/6dea685))
- support history mode ([f095eb8](https://github.com/QingWei-Li/docsify/commit/f095eb8))

## [3.7.3](https://github.com/docsifyjs/docsify/compare/v3.7.2...v3.7.3) (2017-05-22)


### Bug Fixes

* **render:** find => filter ([eca3368](https://github.com/docsifyjs/docsify/commit/eca33681524d7047080c817d202d7b7d188634ea))



## [3.7.2](https://github.com/docsifyjs/docsify/compare/v3.7.1...v3.7.2) (2017-05-19)



## [3.7.1](https://github.com/docsifyjs/docsify/compare/v3.7.0...v3.7.1) (2017-05-19)


### Bug Fixes

* docsify-updated is undefined ([b2b4742](https://github.com/docsifyjs/docsify/commit/b2b474264f3a618d370a632713258e98278c732e))



# [3.7.0](https://github.com/docsifyjs/docsify/compare/v3.6.6...v3.7.0) (2017-05-16)


### Features

* add docsify-updated, close [#158](https://github.com/docsifyjs/docsify/issues/158) ([d2be5ae](https://github.com/docsifyjs/docsify/commit/d2be5aecf8fe65a8f9443c023f8b5e9fe035bf6c))
* add externalLinkTarget, close [#149](https://github.com/docsifyjs/docsify/issues/149) ([2d73285](https://github.com/docsifyjs/docsify/commit/2d73285de505d5dd4afdc62c3b5463cf17f21109))



## [3.6.6](https://github.com/docsifyjs/docsify/compare/v3.6.5...v3.6.6) (2017-05-06)


### Features

* support query string for the search, fixed [#156](https://github.com/docsifyjs/docsify/issues/156) ([da75d70](https://github.com/docsifyjs/docsify/commit/da75d70dee4f0b7e5f07d2f06a3d437aff5980b3))



## [3.6.5](https://github.com/docsifyjs/docsify/compare/v3.6.4...v3.6.5) (2017-04-28)


### Bug Fixes

* **util:** fix crash, fixed [#154](https://github.com/docsifyjs/docsify/issues/154) ([51832d3](https://github.com/docsifyjs/docsify/commit/51832d3506b23b1a1335c1c2b907afd1ccada755))



## [3.6.4](https://github.com/docsifyjs/docsify/compare/v3.6.3...v3.6.4) (2017-04-28)


### Bug Fixes

* **util:** correctly clean up duplicate slashes, fixed [#153](https://github.com/docsifyjs/docsify/issues/153) ([76c041a](https://github.com/docsifyjs/docsify/commit/76c041ad48cd4edc73d7114a80e9c2b85fddee52))



## [3.6.3](https://github.com/docsifyjs/docsify/compare/v3.6.2...v3.6.3) (2017-04-25)


### Bug Fixes

* **external-script:** script attrs ([2653849](https://github.com/docsifyjs/docsify/commit/2653849a3ed1d16ec36cf3733bac203761b964db))



## [3.6.2](https://github.com/docsifyjs/docsify/compare/v3.6.0...v3.6.2) (2017-04-12)


### Features

* **event:** Collapse the sidebar when click outside element in the small screen ([9b7e5f5](https://github.com/docsifyjs/docsify/commit/9b7e5f5814119a22742867084c33e8f7ac894d5f))
* **external-script:** detect more than one script dom, fixed [#146](https://github.com/docsifyjs/docsify/issues/146) ([94d6603](https://github.com/docsifyjs/docsify/commit/94d6603c06a37f88daca25359cc1d1f6cf604014))



# [3.6.0](https://github.com/docsifyjs/docsify/compare/v3.5.2...v3.6.0) (2017-04-09)


### Features

* **render:** add mergeNavbar option, close [#125](https://github.com/docsifyjs/docsify/issues/125), [#124](https://github.com/docsifyjs/docsify/issues/124) ([#145](https://github.com/docsifyjs/docsify/issues/145)) ([9220523](https://github.com/docsifyjs/docsify/commit/9220523a40494fa2687ac3f7f722db2909f9e814))



## [3.5.2](https://github.com/docsifyjs/docsify/compare/v3.5.1...v3.5.2) (2017-04-05)



## [3.5.1](https://github.com/docsifyjs/docsify/compare/v3.5.0...v3.5.1) (2017-03-25)


### Bug Fixes

* .md file extension regex ([594299f](https://github.com/docsifyjs/docsify/commit/594299ffbd04018dfab610091d959fa86a2db2af))



# [3.5.0](https://github.com/docsifyjs/docsify/compare/v3.4.4...v3.5.0) (2017-03-25)


### Bug Fixes

* adjust display on small screens ([bf35471](https://github.com/docsifyjs/docsify/commit/bf35471a2b88d681d84ed1a34cf26f0dc3839a22))
* navbar labels for German ([b022aaf](https://github.com/docsifyjs/docsify/commit/b022aaf14e7276400d69c14e2519cab31a5b4986))


### Features

* **route:** auto remove .md extension ([8f11653](https://github.com/docsifyjs/docsify/commit/8f11653b415cbf978578213113f19ec0cf6d3d9a))



## [3.4.4](https://github.com/docsifyjs/docsify/compare/v3.4.3...v3.4.4) (2017-03-17)


### Bug Fixes

* **search:** fix input style ([2d6a51b](https://github.com/docsifyjs/docsify/commit/2d6a51b057ae5fe299e5adb488b87aed820f28c0))



## [3.4.3](https://github.com/docsifyjs/docsify/compare/v3.4.2...v3.4.3) (2017-03-16)



## [3.4.2](https://github.com/docsifyjs/docsify/compare/v3.4.1...v3.4.2) (2017-03-11)


### Features

* **emojify:** add no-emoji option ([3aef37a](https://github.com/docsifyjs/docsify/commit/3aef37a445a0b68bf1bd525f0e8d10f63d08b562))



## [3.4.1](https://github.com/docsifyjs/docsify/compare/v3.4.0...v3.4.1) (2017-03-10)


### Bug Fixes

* **dom:** Disable the dom cache when vue is present, fixed [#119](https://github.com/docsifyjs/docsify/issues/119) ([b9a7275](https://github.com/docsifyjs/docsify/commit/b9a7275c8f08f0d6810be831b36a5d7ecdff0e4c))



# [3.4.0](https://github.com/docsifyjs/docsify/compare/v3.3.0...v3.4.0) (2017-03-09)


### Features

* **zoom-image:** add plugin ([50fa6fc](https://github.com/docsifyjs/docsify/commit/50fa6fcb89fc575687cededc670abef7c20bbbee))



# [3.3.0](https://github.com/docsifyjs/docsify/compare/v3.2.0...v3.3.0) (2017-03-07)



# [3.2.0](https://github.com/docsifyjs/docsify/compare/v3.1.2...v3.2.0) (2017-02-28)


### Bug Fixes

* **fetch:** load sidebar and navbar for parent path, fixed [#100](https://github.com/docsifyjs/docsify/issues/100) ([f3fc596](https://github.com/docsifyjs/docsify/commit/f3fc5969512941416fb5082654f146153943715b))
* **render:** Toc rendering error, fixed [#106](https://github.com/docsifyjs/docsify/issues/106) ([0d59ee9](https://github.com/docsifyjs/docsify/commit/0d59ee939fac6b0a8980c0e24d2da5f654227052))


### Features

* **search:** Localization for no data tip, close [#103](https://github.com/docsifyjs/docsify/issues/103) ([d3c9fbd](https://github.com/docsifyjs/docsify/commit/d3c9fbd124b4cec16293e93a6c2f000d767e163a))



## [3.1.2](https://github.com/docsifyjs/docsify/compare/v3.1.1...v3.1.2) (2017-02-27)



## [3.1.1](https://github.com/docsifyjs/docsify/compare/v3.1.0...v3.1.1) (2017-02-24)


### Bug Fixes

* **render:** custom cover background image ([8f9bf29](https://github.com/docsifyjs/docsify/commit/8f9bf29ee5a75f8774897294ca639f7efb55d43c))
* **search:** dont search nameLink, fixed [#102](https://github.com/docsifyjs/docsify/issues/102) ([507d9e8](https://github.com/docsifyjs/docsify/commit/507d9e834c2867676c31b1bfb43517b79089f88a))
* **tpl:** extra character, fixed [#101](https://github.com/docsifyjs/docsify/issues/101) ([d67d25f](https://github.com/docsifyjs/docsify/commit/d67d25fed4b1509562db03d9576c2538c6b311ab))



# [3.1.0](https://github.com/docsifyjs/docsify/compare/v3.0.5...v3.1.0) (2017-02-22)


### Bug Fixes

* **search:** incorrect anchor link, fixed [#90](https://github.com/docsifyjs/docsify/issues/90) ([b8a3d8f](https://github.com/docsifyjs/docsify/commit/b8a3d8f38094f7270bb37fde38d278fe43b6b827))
* **sw:** update white list ([f2975a5](https://github.com/docsifyjs/docsify/commit/f2975a5e5e40105d57a2885e416eef31fcb4e2f5))


### Features

* **emoji:** add emoji plugin ([855c450](https://github.com/docsifyjs/docsify/commit/855c450a97615b0ff0087c4cf0d2366bf0bae82c))



## [3.0.5](https://github.com/docsifyjs/docsify/compare/v3.0.4...v3.0.5) (2017-02-21)


### Bug Fixes

* **event:** highlight sidebar when clicked, fixed [#86](https://github.com/docsifyjs/docsify/issues/86) ([2a1157a](https://github.com/docsifyjs/docsify/commit/2a1157a70679be86cda09a5ecca8004316ae95fb))
* **gen-tree:** cache toc list, fixed [#88](https://github.com/docsifyjs/docsify/issues/88) ([3394ebb](https://github.com/docsifyjs/docsify/commit/3394ebb9a5eef54920fea3b5f0c6ebd8272322f7))
* **layout.css:** loading style ([42b2dba](https://github.com/docsifyjs/docsify/commit/42b2dba589410fe35fb42306d540c933f7e07887))


### Features

* **pwa:** add sw.js ([f7111b5](https://github.com/docsifyjs/docsify/commit/f7111b59038645a5fb50839add67f0c871278e40))



## [3.0.4](https://github.com/docsifyjs/docsify/compare/v3.0.3...v3.0.4) (2017-02-20)


### Bug Fixes

* **render:** disable rendering sub list when loadSidebar is false ([35dd2e1](https://github.com/docsifyjs/docsify/commit/35dd2e16fab460bfc77d836f607c374c57ec8426))
* **render:** execute script ([780c1e5](https://github.com/docsifyjs/docsify/commit/780c1e580e6c598703cfae381cb537b8c5849c7d))



## [3.0.3](https://github.com/docsifyjs/docsify/compare/v3.0.2...v3.0.3) (2017-02-19)



## [3.0.2](https://github.com/docsifyjs/docsify/compare/v3.0.1...v3.0.2) (2017-02-19)


### Bug Fixes

* **compiler:** link ([3b127a1](https://github.com/docsifyjs/docsify/commit/3b127a161c3f33f9817eb834f778eb3382653ec4))
* **search:** add lazy input ([bf593a7](https://github.com/docsifyjs/docsify/commit/bf593a77ad4884275921abefc1f78e897b292172))



## [3.0.1](https://github.com/docsifyjs/docsify/compare/v3.0.0...v3.0.1) (2017-02-19)


### Bug Fixes

* **route:** empty alias ([cd99b52](https://github.com/docsifyjs/docsify/commit/cd99b522e79a611fe6de6344c1a3b5cc9176f6f9))



# [3.0.0](https://github.com/docsifyjs/docsify/compare/v2.4.3...v3.0.0) (2017-02-19)


### Bug Fixes

* **compiler:** link ([c7e09c3](https://github.com/docsifyjs/docsify/commit/c7e09c34a719180d9a752d9fa44835a5de37dc3d))
* **render:** support html file ([7b6a2ac](https://github.com/docsifyjs/docsify/commit/7b6a2ac404110b153b5fc2ee60adf19a0270f22c))
* **search:** escape html ([fcb66e8](https://github.com/docsifyjs/docsify/commit/fcb66e8bc78884c38cf96cb328ad07f50cdb4a5e))
* **search:** fix default config ([2efd859](https://github.com/docsifyjs/docsify/commit/2efd859f71d14904c8fda0fb24a8f2d2bda66705))


### Features

* **front-matter:** add front matter[WIP] ([dbb9278](https://github.com/docsifyjs/docsify/commit/dbb92782cf6a0a6e551e64d7eaef4609823ce355))
* **render:** add auto header ([b7768b1](https://github.com/docsifyjs/docsify/commit/b7768b1b3c1a9914427c7219351ae1d8c60650a5))
* **search:** Localization for search placeholder, close [#80](https://github.com/docsifyjs/docsify/issues/80) ([2351c3e](https://github.com/docsifyjs/docsify/commit/2351c3e68c4b77ddd0cd62dcf2164df6d46b0e66))
* **themes:** add loading info ([86594a3](https://github.com/docsifyjs/docsify/commit/86594a31184c2247d01d453a15cb2bb221493598))



## [2.4.3](https://github.com/docsifyjs/docsify/compare/v2.4.2...v2.4.3) (2017-02-15)



## [2.4.2](https://github.com/docsifyjs/docsify/compare/v2.4.1...v2.4.2) (2017-02-14)


### Bug Fixes

* **index:** load file path error ([dc536a3](https://github.com/docsifyjs/docsify/commit/dc536a39301ae2853c8ac9b9fc68da33d2b2ae91))



## [2.4.1](https://github.com/docsifyjs/docsify/compare/v2.4.0...v2.4.1) (2017-02-13)


### Bug Fixes

* **index:** cover page ([dd0c84b](https://github.com/docsifyjs/docsify/commit/dd0c84bb40b1956310611b005d7cfd77d2cba459))



# [2.4.0](https://github.com/docsifyjs/docsify/compare/v2.3.0...v2.4.0) (2017-02-13)


### Features

* **hook:** add doneEach ([c6f7602](https://github.com/docsifyjs/docsify/commit/c6f760275cb703a5d2ab024bdc8abef9c468769a))



# [2.3.0](https://github.com/docsifyjs/docsify/compare/v2.2.1...v2.3.0) (2017-02-13)


### Bug Fixes

* **event:**  has no effect on a FF mobile browser, fixed [#67](https://github.com/docsifyjs/docsify/issues/67) ([0ff36c2](https://github.com/docsifyjs/docsify/commit/0ff36c22bbf3f8de1647abc5b283259917edf065))
* **render:** custom marked renderer ([bf559b4](https://github.com/docsifyjs/docsify/commit/bf559b44dc6fe043890874df01b49f5a19eb7305))
* **render:** fix render link ([a866744](https://github.com/docsifyjs/docsify/commit/a866744c4517e9ab6449bc3ca936fd6c7366309a))
* **render:** image url ([6f87529](https://github.com/docsifyjs/docsify/commit/6f8752925672c8288fc4a8d68a99d14edfdd402f))
* **render:** render link ([38ea660](https://github.com/docsifyjs/docsify/commit/38ea660b78ede460e0760abbc6b2db3d5b0c2766))
* **src:** fix route ([324301a](https://github.com/docsifyjs/docsify/commit/324301aaff4dc1e84e046235e6f490aec44d20b8))
* **src:** get alias ([784173e](https://github.com/docsifyjs/docsify/commit/784173e4c874ce6ff39f718d30625a268024f4d5))
* **src:** get alias ([ce99a04](https://github.com/docsifyjs/docsify/commit/ce99a04f2e8e95c694424fe45fb969b02192b75b))
* **themes:** fix navbar style ([fa54b52](https://github.com/docsifyjs/docsify/commit/fa54b52048b63bafa4dd134544f4cb46cbb22ba0))
* **themes:** update navbar style ([4864d1b](https://github.com/docsifyjs/docsify/commit/4864d1b26f03b1c5607448ea8402e3037c2b294b))


### Features

* **hook:** support custom plugin ([9e81a59](https://github.com/docsifyjs/docsify/commit/9e81a5975f42a7dde64e4085c6389029f22c85d0))
* **src:** add alias feature ([24412cd](https://github.com/docsifyjs/docsify/commit/24412cdaf0dbe241aeab0bb97d0847b8245a5aca))
* **src:** dynamic title and fix sidebar style ([6b30eb6](https://github.com/docsifyjs/docsify/commit/6b30eb65eb40a9636455ec078e644382e1d7e7aa))



## [2.2.1](https://github.com/docsifyjs/docsify/compare/v2.2.0...v2.2.1) (2017-02-11)


### Bug Fixes

* **event:** scroll active sidebar ([50f5fc2](https://github.com/docsifyjs/docsify/commit/50f5fc2b224859c413b372a0ae63a8dc917dd082))
* **search:** crash when not content, fixed [#68](https://github.com/docsifyjs/docsify/issues/68) ([9d3cc89](https://github.com/docsifyjs/docsify/commit/9d3cc89aa93c025fac224ec7c868693592f2c4f7))
* **search:** not work in mobile ([3941304](https://github.com/docsifyjs/docsify/commit/3941304fda681dfee1df03577dec8b829ac270ad))



# [2.2.0](https://github.com/docsifyjs/docsify/compare/v2.1.0...v2.2.0) (2017-02-09)


### Features

* **plugins:** add Google Analytics plugin ([#66](https://github.com/docsifyjs/docsify/issues/66)) ([ac61bb0](https://github.com/docsifyjs/docsify/commit/ac61bb0e75d72e6ecd1b0b7be9f4506cc6f7354a))



# [2.1.0](https://github.com/docsifyjs/docsify/compare/v2.0.3...v2.1.0) (2017-02-09)


### Bug Fixes

* render name ([12e2479](https://github.com/docsifyjs/docsify/commit/12e24790142cfa9792700d3fc89abe4cf92205e7))
* **vue.css:** update sidebar style ([fc140ef](https://github.com/docsifyjs/docsify/commit/fc140ef957565c4fc5f49d1873a77d0ee8f0abbd))


### Features

* add search, close [#43](https://github.com/docsifyjs/docsify/issues/43) ([eb5ff3e](https://github.com/docsifyjs/docsify/commit/eb5ff3e987f0275f6e2ddcedfa57768f2976eae1))



## [2.0.3](https://github.com/docsifyjs/docsify/compare/v2.0.2...v2.0.3) (2017-02-07)


### Bug Fixes

* css var polyfill ([8cd386a](https://github.com/docsifyjs/docsify/commit/8cd386ae4970c569e2b76a44e57e5066fc9c3db2))
* css var polyfill ([cbaee21](https://github.com/docsifyjs/docsify/commit/cbaee21deddf4a568de3a408c74a380a383ef88a))
* rendering emojis ([8c7e4d7](https://github.com/docsifyjs/docsify/commit/8c7e4d7866049db20871624140640e08dc5f55b7))



## [2.0.2](https://github.com/docsifyjs/docsify/compare/v2.0.1...v2.0.2) (2017-02-05)


### Bug Fixes

* button style in cover page ([4470855](https://github.com/docsifyjs/docsify/commit/44708554f74b4a29059bc89baa6e001637b972c0))



## [2.0.1](https://github.com/docsifyjs/docsify/compare/v2.0.0...v2.0.1) (2017-02-05)



# [2.0.0](https://github.com/docsifyjs/docsify/compare/v1.10.5...v2.0.0) (2017-02-05)


### Features

* customize the theme color ([5cc9f05](https://github.com/docsifyjs/docsify/commit/5cc9f0514c04805cf1d9ec324a634644ba28a145))



## [1.10.5](https://github.com/docsifyjs/docsify/compare/v1.10.4...v1.10.5) (2017-01-28)



## [1.10.4](https://github.com/docsifyjs/docsify/compare/v1.10.3...v1.10.4) (2017-01-27)



## [1.10.3](https://github.com/docsifyjs/docsify/compare/v1.10.2...v1.10.3) (2017-01-27)



## [1.10.2](https://github.com/docsifyjs/docsify/compare/v1.10.1...v1.10.2) (2017-01-25)



## [1.10.1](https://github.com/docsifyjs/docsify/compare/v1.10.0...v1.10.1) (2017-01-25)



# [1.10.0](https://github.com/docsifyjs/docsify/compare/v1.9.0...v1.10.0) (2017-01-25)



# [1.9.0](https://github.com/docsifyjs/docsify/compare/v1.8.0...v1.9.0) (2017-01-24)



# [1.8.0](https://github.com/docsifyjs/docsify/compare/v1.7.4...v1.8.0) (2017-01-24)



## [1.7.4](https://github.com/docsifyjs/docsify/compare/v1.7.3...v1.7.4) (2017-01-13)



## [1.7.3](https://github.com/docsifyjs/docsify/compare/v1.7.2...v1.7.3) (2017-01-13)



## [1.7.2](https://github.com/docsifyjs/docsify/compare/v1.7.1...v1.7.2) (2017-01-12)



## [1.7.1](https://github.com/docsifyjs/docsify/compare/v1.7.0...v1.7.1) (2017-01-12)



# [1.7.0](https://github.com/docsifyjs/docsify/compare/v1.6.1...v1.7.0) (2017-01-12)



## [1.6.1](https://github.com/docsifyjs/docsify/compare/v1.6.0...v1.6.1) (2017-01-10)



# [1.6.0](https://github.com/docsifyjs/docsify/compare/v1.5.2...v1.6.0) (2017-01-10)



## [1.5.2](https://github.com/docsifyjs/docsify/compare/v1.5.1...v1.5.2) (2017-01-10)



## [1.5.1](https://github.com/docsifyjs/docsify/compare/v1.5.0...v1.5.1) (2017-01-09)



# [1.5.0](https://github.com/docsifyjs/docsify/compare/v1.4.3...v1.5.0) (2017-01-04)


### Features

* Markdown parser is configurable, [#42](https://github.com/docsifyjs/docsify/issues/42) ([8b1000a](https://github.com/docsifyjs/docsify/commit/8b1000a4a55532419d8f8e41b797c15e2a5442cc))



## [1.4.3](https://github.com/docsifyjs/docsify/compare/v1.4.2...v1.4.3) (2017-01-01)



## [1.4.2](https://github.com/docsifyjs/docsify/compare/v1.4.1...v1.4.2) (2016-12-31)



## [1.4.1](https://github.com/docsifyjs/docsify/compare/v1.4.0...v1.4.1) (2016-12-31)



# [1.4.0](https://github.com/docsifyjs/docsify/compare/v1.3.5...v1.4.0) (2016-12-31)



## [1.3.5](https://github.com/docsifyjs/docsify/compare/v1.3.4...v1.3.5) (2016-12-25)



## [1.3.4](https://github.com/docsifyjs/docsify/compare/v1.3.3...v1.3.4) (2016-12-25)



## [1.3.3](https://github.com/docsifyjs/docsify/compare/v1.3.2...v1.3.3) (2016-12-23)



## [1.3.2](https://github.com/docsifyjs/docsify/compare/v1.3.1...v1.3.2) (2016-12-22)



## [1.3.1](https://github.com/docsifyjs/docsify/compare/v1.3.0...v1.3.1) (2016-12-22)



# [1.3.0](https://github.com/docsifyjs/docsify/compare/v1.2.0...v1.3.0) (2016-12-21)



# [1.2.0](https://github.com/docsifyjs/docsify/compare/v1.1.7...v1.2.0) (2016-12-20)



## [1.1.7](https://github.com/docsifyjs/docsify/compare/v1.1.6...v1.1.7) (2016-12-19)



## [1.1.6](https://github.com/docsifyjs/docsify/compare/v1.1.5...v1.1.6) (2016-12-18)



## [1.1.5](https://github.com/docsifyjs/docsify/compare/v1.1.4...v1.1.5) (2016-12-18)



## [1.1.4](https://github.com/docsifyjs/docsify/compare/v1.1.3...v1.1.4) (2016-12-17)



## [1.1.3](https://github.com/docsifyjs/docsify/compare/v1.1.2...v1.1.3) (2016-12-17)



## [1.1.2](https://github.com/docsifyjs/docsify/compare/v1.1.1...v1.1.2) (2016-12-17)



## [1.1.1](https://github.com/docsifyjs/docsify/compare/v1.1.0...v1.1.1) (2016-12-17)



# [1.1.0](https://github.com/docsifyjs/docsify/compare/v1.0.3...v1.1.0) (2016-12-16)



## [1.0.3](https://github.com/docsifyjs/docsify/compare/v1.0.2...v1.0.3) (2016-12-13)



## [1.0.2](https://github.com/docsifyjs/docsify/compare/v1.0.1...v1.0.2) (2016-12-13)



## [1.0.1](https://github.com/docsifyjs/docsify/compare/v1.0.0...v1.0.1) (2016-12-08)



# [1.0.0](https://github.com/docsifyjs/docsify/compare/v0.7.0...v1.0.0) (2016-12-08)



# [0.7.0](https://github.com/docsifyjs/docsify/compare/v0.6.1...v0.7.0) (2016-11-30)



## [0.6.1](https://github.com/docsifyjs/docsify/compare/v0.6.0...v0.6.1) (2016-11-29)



# [0.6.0](https://github.com/docsifyjs/docsify/compare/v0.5.0...v0.6.0) (2016-11-29)



# [0.5.0](https://github.com/docsifyjs/docsify/compare/v0.4.2...v0.5.0) (2016-11-28)



## [0.4.2](https://github.com/docsifyjs/docsify/compare/v0.4.1...v0.4.2) (2016-11-28)



## [0.4.1](https://github.com/docsifyjs/docsify/compare/v0.4.0...v0.4.1) (2016-11-28)



# [0.4.0](https://github.com/docsifyjs/docsify/compare/v0.3.1...v0.4.0) (2016-11-27)


### Features

* custom sidebar, [#4](https://github.com/docsifyjs/docsify/issues/4) ([#5](https://github.com/docsifyjs/docsify/issues/5)) ([37e7984](https://github.com/docsifyjs/docsify/commit/37e7984e7efab3767badb9d940b7368b2b6f8493))



## [0.3.1](https://github.com/docsifyjs/docsify/compare/v0.3.0...v0.3.1) (2016-11-27)



# [0.3.0](https://github.com/docsifyjs/docsify/compare/v0.2.1...v0.3.0) (2016-11-27)



## [0.2.1](https://github.com/docsifyjs/docsify/compare/v0.2.0...v0.2.1) (2016-11-26)



# [0.2.0](https://github.com/docsifyjs/docsify/compare/v0.1.0...v0.2.0) (2016-11-26)



# [0.1.0](https://github.com/docsifyjs/docsify/compare/v0.0.5...v0.1.0) (2016-11-26)



## [0.0.5](https://github.com/docsifyjs/docsify/compare/v0.0.4...v0.0.5) (2016-11-24)



## [0.0.4](https://github.com/docsifyjs/docsify/compare/v0.0.3...v0.0.4) (2016-11-22)



## [0.0.3](https://github.com/docsifyjs/docsify/compare/v0.0.2...v0.0.3) (2016-11-20)



## [0.0.2](https://github.com/docsifyjs/docsify/compare/v0.0.1...v0.0.2) (2016-11-20)



## 0.0.1 (2016-11-20)
